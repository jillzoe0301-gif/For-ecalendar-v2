import { createClient } from '@supabase/supabase-js'
import './style.css'

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL || ''
const SUPABASE_ANON_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY || ''
const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY)

const pages = [
  { key: 'personalSchedule', label: '個人行程表', mobileLabel: '個人', roles: 'ALL', mobile: true },
  { key: 'personalTodo', label: '個人一般待辦', mobileLabel: '待辦', roles: 'ALL', mobile: true },
  { key: 'scheduleOverview', label: '行程總覽', mobileLabel: '行程', roles: 'ALL', mobile: true },
  { key: 'fieldSchedule', label: '外務行程', mobileLabel: '外務', roles: ['管理員', '主管', '行政 / 海外'], mobile: true },
  { key: 'fieldDetail', label: '外務明細', mobileLabel: '明細', roles: ['管理員', '行政 / 海外'], mobile: false },
  { key: 'meetingRoom', label: '會議室預約', mobileLabel: '會議室', roles: ['管理員', '主管', '行政 / 海外', '外務 / 宿管人員 / 會計', '一般職員'], mobile: true },
  { key: 'incident', label: '異況追蹤', mobileLabel: '異況', roles: ['管理員', '主管', '行政 / 海外'], mobile: true },
  { key: 'search', label: '行程搜尋', mobileLabel: '搜尋', roles: ['管理員', '主管', '行政 / 海外'], mobile: false },
  { key: 'stats', label: '統計報表', mobileLabel: '統計', roles: ['管理員', '主管'], mobile: false },
  { key: 'serviceRecord', label: '服務紀錄單', mobileLabel: '紀錄', roles: ['管理員', '主管'], mobile: false },
  { key: 'recordSubmit', label: '紀錄單繳交', mobileLabel: '繳交', roles: ['翻譯'], mobile: true },
  { key: 'line', label: 'LINE 通知', mobileLabel: 'LINE', roles: 'ALL', mobile: true },
  { key: 'color', label: '顏色設定', mobileLabel: '顏色', roles: ['管理員', '主管', '行政 / 海外', '外務 / 宿管人員 / 會計', '一般職員'], mobile: false },
  { key: 'options', label: '選項管理', mobileLabel: '選項', roles: ['管理員'], mobile: false },
  { key: 'audit', label: '異動紀錄', mobileLabel: '紀錄', roles: ['管理員', '主管', '行政 / 海外', '外務 / 宿管人員 / 會計', '一般職員'], mobile: false },
  { key: 'users', label: '人員 / 帳號', mobileLabel: '帳號', roles: ['管理員', '主管', '行政 / 海外', '翻譯', '外務 / 宿管人員 / 會計', '一般職員'], mobile: true }
]

const formCategories = ['服務行程', '一般記事', '待辦事項', '請假 / 會議 / 活動 / 外訓']
const serviceScheduleTypes = [
  '面談', '上線 / 教育訓練', '定期 / 開會', '送工', '銀行', '醫療',
  '車禍處理', '結薪', '收送簽文件', '逃跑通知', '轉出追蹤',
  '住變資訊', '驗證提醒', '返台提醒', '宿舍', '其他'
]
const todoItems = ['送件', '補件', '登記', '回覆', '追蹤']
const leaveMeetingTypes = ['請假', '返鄉', '會議', '外訓', '公司活動', '部門活動']
const carOptions = ['不使用', 'A車', 'B車', 'C車', '其他']
const documentOptions = ['護照', '居留證', '健保卡', '印章', '其他']
const weekdays = [
  ['MO', '週一'], ['TU', '週二'], ['WE', '週三'], ['TH', '週四'],
  ['FR', '週五'], ['SA', '週六'], ['SU', '週日']
]

const holidayMaps = {
  2026: {
    tw: {
      '2026-01-01': ['元旦'],
      '2026-02-16': ['除夕'],
      '2026-02-17': ['春節'],
      '2026-02-18': ['春節'],
      '2026-02-19': ['春節'],
      '2026-02-20': ['春節'],
      '2026-02-27': ['和平紀念日補假'],
      '2026-02-28': ['和平紀念日'],
      '2026-04-03': ['兒童節補假'],
      '2026-04-04': ['兒童節'],
      '2026-04-05': ['清明節'],
      '2026-04-06': ['清明節補假'],
      '2026-05-01': ['勞動節'],
      '2026-06-19': ['端午節'],
      '2026-09-25': ['中秋節'],
      '2026-09-28': ['教師節'],
      '2026-10-10': ['國慶日'],
      '2026-10-25': ['臺灣光復節'],
      '2026-10-26': ['臺灣光復節補假']
    },
    th: {
      '2026-01-01': ['泰國：元旦'],
      '2026-04-13': ['泰國：宋干節'],
      '2026-04-14': ['泰國：宋干節'],
      '2026-04-15': ['泰國：宋干節'],
      '2026-05-01': ['泰國：勞動節'],
      '2026-07-28': ['泰國：國王誕辰'],
      '2026-08-12': ['泰國：母親節'],
      '2026-10-13': ['泰國：蒲美蓬紀念日'],
      '2026-10-23': ['泰國：朱拉隆功紀念日'],
      '2026-12-05': ['泰國：父親節'],
      '2026-12-10': ['泰國：憲法日']
    },
    vn: {
      '2026-01-01': ['越南：元旦'],
      '2026-02-16': ['越南：春節'],
      '2026-02-17': ['越南：春節'],
      '2026-02-18': ['越南：春節'],
      '2026-02-19': ['越南：春節'],
      '2026-02-20': ['越南：春節'],
      '2026-04-30': ['越南：統一日'],
      '2026-05-01': ['越南：勞動節'],
      '2026-09-02': ['越南：國慶日']
    },
    ph: {
      '2026-01-01': ['菲律賓：元旦'],
      '2026-04-09': ['菲律賓：勇士節'],
      '2026-05-01': ['菲律賓：勞動節'],
      '2026-06-12': ['菲律賓：獨立日'],
      '2026-08-31': ['菲律賓：國家英雄日'],
      '2026-11-30': ['菲律賓：博尼法西奧日'],
      '2026-12-25': ['菲律賓：聖誕節'],
      '2026-12-30': ['菲律賓：黎剎日']
    },
    id: {
      '2026-01-01': ['印尼：元旦'],
      '2026-02-16': ['印尼：農曆新年'],
      '2026-03-19': ['印尼：開齋節'],
      '2026-03-20': ['印尼：開齋節'],
      '2026-05-01': ['印尼：勞動節'],
      '2026-05-27': ['印尼：古爾邦節'],
      '2026-08-17': ['印尼：獨立日'],
      '2026-12-25': ['印尼：聖誕節']
    }
  }
}

function getHolidayData(dateKey) {
  const year = Number(dateKey.slice(0, 4))
  const yearMap = holidayMaps[year] || {}
  const tw = yearMap.tw?.[dateKey] || []
  const overseas = [
    ...(yearMap.th?.[dateKey] || []),
    ...(yearMap.vn?.[dateKey] || []),
    ...(yearMap.ph?.[dateKey] || []),
    ...(yearMap.id?.[dateKey] || [])
  ]
  return { tw, overseas }
}

function isTaiwanHoliday(date) {
  const dateKey = toDateKey(date)
  const day = date.getDay()
  return day === 0 || day === 6 || getHolidayData(dateKey).tw.length > 0
}

function renderHolidayLabels(dateKey) {
  const holiday = getHolidayData(dateKey)
  const all = [
    ...holiday.tw.map(name => `<span class="holiday-label tw">${escapeHtml(name)}</span>`),
    ...holiday.overseas.map(name => `<span class="holiday-label overseas">${escapeHtml(name)}</span>`)
  ]
  return all.length ? `<div class="holiday-labels">${all.join('')}</div>` : ''
}



const reminderScheduleTypes = ['逃跑通知', '轉出追蹤', '住變資訊', '返台提醒', '驗證提醒', '追蹤提醒事項']

function isReminderSchedule(row) {
  if (!row) return false
  const typeText = [row.schedule_type, row.sub_type, row.category, row.title].filter(Boolean).join('｜')
  return reminderScheduleTypes.some(type => typeText.includes(type))
}

function isOverdueSchedule(row) {
  if (!row || !row.start_date) return false
  return row.start_date < todayString() && row.status !== '已完成' && row.status !== '取消'
}

function isTodaySchedule(row) {
  return row?.start_date === todayString()
}

function getPersonalReminderRows() {
  return schedules
    .filter(row => isActivePersonalSchedule(row) && isMine(row) && isReminderSchedule(row))
    .filter(row => isTodaySchedule(row) || isOverdueSchedule(row))
    .sort((a, b) => {
      if (isOverdueSchedule(a) !== isOverdueSchedule(b)) return isOverdueSchedule(a) ? -1 : 1
      return String(a.start_date || '').localeCompare(String(b.start_date || ''))
    })
}

function renderPersonalReminderArea() {
  const rows = getPersonalReminderRows()
  if (!rows.length) return ''

  return `
    <section class="personal-reminder-area">
      <div class="reminder-area-title">
        <img src="/icons/reminder-notice.png" alt="提醒">
        <div>
          <strong>待確認 / 待通知提醒</strong>
          <span>逃跑、轉出、住變、返台、驗證與追蹤提醒事項</span>
        </div>
      </div>

      <div class="reminder-card-list">
        ${rows.map(row => {
          const overdue = isOverdueSchedule(row)
          return `
            <button type="button" class="reminder-alert-card ${overdue ? 'is-overdue' : 'is-today'}" data-view-schedule="${row.schedule_id}">
              <div class="reminder-alert-main">
                <div class="reminder-alert-title">${escapeHtml(row.schedule_type || row.category)}｜${escapeHtml(row.title || '-')}</div>
                <div class="reminder-alert-meta">
                  ${escapeHtml(row.start_date || '-')}｜${escapeHtml(formatTime(row))}｜${escapeHtml(getAssigneeNames(row))}
                </div>
                ${row.customer_name || row.location_name ? `<div class="reminder-alert-meta">${escapeHtml(row.customer_name || '')}${row.customer_name && row.location_name ? '｜' : ''}${escapeHtml(row.location_name || '')}</div>` : ''}
              </div>
              ${overdue ? `<div class="reminder-overdue-text">超過時間了!!!</div>` : `<div class="reminder-today-text">今日需處理</div>`}
            </button>
          `
        }).join('')}
      </div>
    </section>
  `
}

let currentProfile = null
let currentPage = 'personalSchedule'
let schedules = []
let staffList = []
let loadingSchedules = false
let schedulesError = ''
let saving = false
let overviewWeekOffset = 0
let searchFilters = {
  keyword: '',
  status: '全部',
  category: '全部',
  staffId: '全部',
  startDate: '',
  endDate: ''
}

let auditLogs = []
let auditLoading = false
let auditError = ''
let auditFilters = {
  keyword: '',
  actionType: '全部',
  startDate: '',
  endDate: ''
}

let serviceRecords = []
let serviceRecordsLoading = false
let serviceRecordsError = ''
let serviceRecordFilters = {
  status: '全部',
  staffId: '全部',
  startDate: '',
  endDate: ''
}

function canSeePage(page, role) {
  return page.roles === 'ALL' || page.roles.includes(role)
}

function isPowerRole() {
  return ['管理員', '主管', '行政 / 海外'].includes(currentProfile?.role)
}

function todayString() {
  return new Date().toISOString().slice(0, 10)
}

function isVisibleSchedule(row) {
  return row && row.status !== '取消' && row.is_cancelled !== true && !row.deleted_at
}

function isActivePersonalSchedule(row) {
  return isVisibleSchedule(row) && row.status !== '已完成' && row.is_completed !== true
}

function isMine(row) {
  const myStaffId = currentProfile?.staff_id
  if (!myStaffId) return false
  if (row.creator_staff_id === myStaffId) return true
  return (row.schedule_assignees || []).some(item => item.staff_id === myStaffId && !item.deleted_at)
}

function isAssignedToMe(row) {
  const myStaffId = currentProfile?.staff_id
  if (!myStaffId) return false
  return (row.schedule_assignees || []).some(item => item.staff_id === myStaffId && !item.deleted_at)
}

function canCompleteSchedule(row) {
  if (!currentProfile) return false
  if (row.status === '已完成' || row.status === '取消') return false
  if (isPowerRole()) return true
  return row.creator_staff_id === currentProfile.staff_id || isAssignedToMe(row)
}

function canCancelSchedule(row) {
  if (!currentProfile) return false
  if (row.status === '取消') return false
  if (isPowerRole()) return true
  return row.creator_staff_id === currentProfile.staff_id
}

function canModifySchedule(row) {
  if (!currentProfile) return false
  if (isPowerRole()) return true
  return row.creator_staff_id === currentProfile.staff_id
}

function formatDate(value) {
  return value || '-'
}

function parseTimeForEdit(value, fallbackHour = '09', fallbackMinute = '00') {
  if (!value) return { hour: fallbackHour, minute: fallbackMinute }
  const text = String(value)
  return {
    hour: text.slice(0, 2) || fallbackHour,
    minute: text.slice(3, 5) || fallbackMinute
  }
}

function formatTime(row) {
  const start = row.start_time ? row.start_time.slice(0, 5) : ''
  const end = row.end_time ? row.end_time.slice(0, 5) : ''
  if (['上午', '下午'].includes(row.time_type) && start && end) return `${row.time_type} ${start}-${end}`
  if (['上午', '下午'].includes(row.time_type) && start) return `${row.time_type} ${start}`
  return row.time_type || '不指定'
}

function getAssigneeIds(row) {
  return (row.schedule_assignees || [])
    .filter(item => !item.deleted_at)
    .map(item => item.staff_id)
}

function getAssigneeNames(row) {
  const names = (row.schedule_assignees || [])
    .filter(item => !item.deleted_at)
    .map(item => item.staff_name)
  return names.length ? names.join('、') : '-'
}

function escapeHtml(value) {
  return String(value ?? '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;')
}

function getFirstTwoLines(text) {
  const raw = String(text || '').trim()
  if (!raw) return ''
  return raw.split(/\r?\n/).slice(0, 2).join('\n')
}

function parseNoteTokens(row) {
  const text = `${row.sub_type_note || ''}｜${row.description || ''}`
  return text
    .split('｜')
    .map(item => item.trim())
    .filter(Boolean)
}

function getNoteValue(row, label) {
  const items = parseNoteTokens(row)
  const found = items.find(item => item.startsWith(label + '：'))
  return found ? found.slice(label.length + 1) : ''
}

function removeNoteLabels(noteText, labels) {
  const items = String(noteText || '').split('｜').map(item => item.trim()).filter(Boolean)
  return items.filter(item => !labels.some(label => item.startsWith(label + '：'))).join('｜')
}

function getReminderTokens(row) {
  const type = row.schedule_type || ''
  const noteItems = parseNoteTokens(row)
  const reminderTypes = ['返台提醒', '逃跑通知', '轉出追蹤', '住變資訊', '驗證提醒']
  const tokens = []

  noteItems.forEach(item => {
    if (
      item.includes('抵台') ||
      item.includes('逃跑') ||
      item.includes('轉出') ||
      item.includes('終止日') ||
      item.includes('住變') ||
      item.includes('驗證') ||
      item.includes('最後工作日') ||
      item.includes('離境') ||
      item.includes('下次回診') ||
      item.includes('證件')
    ) {
      tokens.push(item)
    }
  })

  if (reminderTypes.includes(type) && !tokens.some(item => item.includes(type))) {
    tokens.unshift(type)
  }

  return [...new Set(tokens)].slice(0, 6)
}

function renderBrandLogo(kind = 'horizontal') {
  let src = '/brand/for-e-logo-horizontal.png'
  if (kind === 'icon') src = '/brand/for-e-icon.png'
  if (kind === 'square') src = '/brand/for-e-logo-square.png'
  return `<img class="brand-logo-img ${kind === 'icon' ? 'icon-logo' : ''} ${kind === 'square' ? 'square-logo' : ''}" src="${src}" alt="FOR-e">`
}

function renderLogin() {
  document.querySelector('#app').innerHTML = `
    <section class="login-page">
      <div class="login-card">
        <div class="login-brand">${renderBrandLogo('square')}</div>
        <h1>共享排程系統</h1>
        <p>V002-1E-4｜卡片、證件、提醒與品牌 LOGO</p>

        <label for="email">Email / 帳號</label>
        <input id="email" type="email" placeholder="請輸入 Email" autocomplete="email" />

        <label for="password">密碼</label>
        <input id="password" type="password" placeholder="請輸入密碼" autocomplete="current-password" />

        <button id="loginBtn">登入</button>
        <div id="errorText" class="error"></div>

        <div class="login-note">
          測試項目：行程類型在標題前、卡片內容前兩行、證件欄位、提醒標籤與 LOGO。
        </div>
      </div>
    </section>
  `

  document.querySelector('#loginBtn').addEventListener('click', login)
  document.querySelector('#password').addEventListener('keydown', event => {
    if (event.key === 'Enter') login()
  })
}

async function login() {
  const email = document.querySelector('#email').value.trim()
  const password = document.querySelector('#password').value
  const errorText = document.querySelector('#errorText')
  errorText.textContent = ''

  if (!SUPABASE_URL || !SUPABASE_ANON_KEY) {
    errorText.textContent = '尚未設定 Supabase 環境變數。'
    return
  }

  if (!email || !password) {
    errorText.textContent = '請輸入 Email 與密碼。'
    return
  }

  const { error } = await supabase.auth.signInWithPassword({ email, password })
  if (error) {
    errorText.textContent = `登入失敗：${error.message}`
    return
  }

  await loadProfile()
}

async function loadProfile() {
  const { data: userData } = await supabase.auth.getUser()

  if (!userData.user) {
    renderLogin()
    return
  }

  const { data: profile, error } = await supabase.rpc('get_my_profile').single()

  if (error || !profile) {
    await supabase.auth.signOut()
    renderLogin()
    alert('找不到 profiles，請確認 Supabase 帳號與 profiles 是否正確。')
    return
  }

  if (profile.status !== '啟用') {
    await supabase.auth.signOut()
    renderLogin()
    alert('此帳號已停用，請聯繫管理員。')
    return
  }

  currentProfile = profile
  currentPage = 'personalSchedule'
  await refreshData()
  renderApp()
}

async function refreshData() {
  await Promise.all([loadStaff(), loadSchedules(), loadAuditLogs(), loadServiceRecords()])
}

async function loadStaff() {
  const { data, error } = await supabase
    .from('staff')
    .select('staff_id, name, department_id, department_name, position, role, status, deleted_at')
    .eq('status', '啟用')
    .is('deleted_at', null)
    .order('display_order', { ascending: true })

  if (error) {
    console.error(error)
    staffList = []
    return
  }

  staffList = data || []
}

async function loadSchedules() {
  loadingSchedules = true
  schedulesError = ''

  const { data, error } = await supabase
    .from('schedules')
    .select('*, schedule_assignees(*)')
    .is('deleted_at', null)
    .order('start_date', { ascending: true })
    .order('start_time', { ascending: true })

  if (error) {
    console.error(error)
    schedules = []
    schedulesError = error.message
  } else {
    schedules = data || []
  }

  loadingSchedules = false
}


async function loadAuditLogs() {
  auditLoading = true
  auditError = ''

  const { data, error } = await supabase
    .from('audit_logs')
    .select('*')
    .order('created_at', { ascending: false })
    .limit(300)

  if (error) {
    console.error(error)
    auditLogs = []
    auditError = error.message
  } else {
    auditLogs = data || []
  }

  auditLoading = false
}


async function loadServiceRecords() {
  serviceRecordsLoading = true
  serviceRecordsError = ''

  const { data, error } = await supabase
    .from('service_records')
    .select('*')
    .order('schedule_date', { ascending: false })
    .limit(500)

  if (error) {
    console.error(error)
    serviceRecords = []
    serviceRecordsError = error.message
  } else {
    serviceRecords = data || []
  }

  serviceRecordsLoading = false
}

function renderApp() {
  const visiblePages = pages.filter(page => canSeePage(page, currentProfile.role))
  const mobilePages = visiblePages.filter(page => page.mobile)

  document.querySelector('#app').innerHTML = `
    <section class="layout">
      <aside class="sidebar">
        <div class="brand">
          <div class="brand-logo-wrap">${renderBrandLogo('horizontal')}</div>
          <div class="brand-subtitle">共享排程系統</div>
        </div>

        <nav class="desktop-menu">
          ${visiblePages.map(page => `
            <button class="menu-btn ${page.key === currentPage ? 'active' : ''}" data-page="${page.key}">
              ${page.label}
            </button>
          `).join('')}
        </nav>
      </aside>

      <main class="main">
        <header class="mobile-header">
          ${renderBrandLogo('icon')}
          <span>FOR-e</span>
        </header>

        <header class="topbar">
          <div>
            <h2>${getPageTitle()}</h2>
            <p>
              ${currentProfile.name || currentProfile.email}
              ｜${currentProfile.role}
              ｜${currentProfile.department_name || '-'}
              ｜${currentProfile.position_name || currentProfile.position || '-'}
            </p>
          </div>
          <button class="logout-btn" id="logoutBtn">登出</button>
        </header>

        <section class="content-card">
          ${renderPageContent()}
        </section>
      </main>

      <nav class="mobile-nav">
        ${mobilePages.map(page => `
          <button class="${page.key === currentPage ? 'active' : ''}" data-page="${page.key}">
            ${page.mobileLabel}
          </button>
        `).join('')}
      </nav>
    </section>
  `

  document.querySelectorAll('[data-page]').forEach(btn => {
    btn.addEventListener('click', () => {
      currentPage = btn.dataset.page
      renderApp()
    })
  })

  document.querySelector('#logoutBtn').addEventListener('click', logout)

  const refreshBtn = document.querySelector('#refreshBtn')
  if (refreshBtn) {
    refreshBtn.addEventListener('click', async () => {
      await refreshData()
      renderApp()
    })
  }

  const resetSearchBtn = document.querySelector('#resetSearchBtn')
  if (resetSearchBtn) {
    resetSearchBtn.addEventListener('click', () => {
      searchFilters = {
        keyword: '',
        status: '全部',
        category: '全部',
        staffId: '全部',
        startDate: '',
        endDate: ''
      }
      renderApp()
    })
  }

  const searchForm = document.querySelector('#searchForm')
  if (searchForm) {
    searchForm.addEventListener('submit', event => {
      event.preventDefault()
      const form = new FormData(event.target)
      searchFilters = {
        keyword: form.get('keyword') || '',
        status: form.get('status') || '全部',
        category: form.get('category') || '全部',
        staffId: form.get('staffId') || '全部',
        startDate: form.get('startDate') || '',
        endDate: form.get('endDate') || ''
      }
      renderApp()
    })
  }

  const resetAuditBtn = document.querySelector('#resetAuditBtn')
  if (resetAuditBtn) {
    resetAuditBtn.addEventListener('click', () => {
      auditFilters = {
        keyword: '',
        actionType: '全部',
        startDate: '',
        endDate: ''
      }
      renderApp()
    })
  }

  const auditForm = document.querySelector('#auditForm')
  if (auditForm) {
    auditForm.addEventListener('submit', event => {
      event.preventDefault()
      const form = new FormData(event.target)
      auditFilters = {
        keyword: form.get('keyword') || '',
        actionType: form.get('actionType') || '全部',
        startDate: form.get('startDate') || '',
        endDate: form.get('endDate') || ''
      }
      renderApp()
    })
  }

  
  const resetServiceRecordFilterBtn = document.querySelector('#resetServiceRecordFilterBtn')
  if (resetServiceRecordFilterBtn) {
    resetServiceRecordFilterBtn.addEventListener('click', () => {
      serviceRecordFilters = {
        status: '全部',
        staffId: '全部',
        startDate: '',
        endDate: ''
      }
      renderApp()
    })
  }

  const serviceRecordFilterForm = document.querySelector('#serviceRecordFilterForm')
  if (serviceRecordFilterForm) {
    serviceRecordFilterForm.addEventListener('submit', event => {
      event.preventDefault()
      const form = new FormData(event.target)
      serviceRecordFilters = {
        status: form.get('status') || '全部',
        staffId: form.get('staffId') || '全部',
        startDate: form.get('startDate') || '',
        endDate: form.get('endDate') || ''
      }
      renderApp()
    })
  }

  const prevWeekBtn = document.querySelector('#prevWeekBtn')
  if (prevWeekBtn) {
    prevWeekBtn.addEventListener('click', () => {
      overviewWeekOffset -= 1
      renderApp()
    })
  }

  const thisWeekBtn = document.querySelector('#thisWeekBtn')
  if (thisWeekBtn) {
    thisWeekBtn.addEventListener('click', () => {
      overviewWeekOffset = 0
      renderApp()
    })
  }

  const nextWeekBtn = document.querySelector('#nextWeekBtn')
  if (nextWeekBtn) {
    nextWeekBtn.addEventListener('click', () => {
      overviewWeekOffset += 1
      renderApp()
    })
  }

  document.querySelectorAll('.week-day-cell').forEach(cell => {
    cell.addEventListener('dblclick', () => openScheduleModal())
  })

  const addBtn = document.querySelector('#addScheduleBtn')
  if (addBtn) addBtn.addEventListener('click', openScheduleModal)

  document.querySelectorAll('[data-view-schedule]').forEach(btn => {
    btn.addEventListener('click', () => openScheduleDetail(btn.dataset.viewSchedule))
  })

  document.querySelectorAll('[data-record-schedule]').forEach(btn => {
    btn.addEventListener('click', () => openServiceRecordModal(btn.dataset.recordSchedule))
  })
}

function getPageTitle() {
  const page = pages.find(item => item.key === currentPage)
  return page ? page.label : '個人行程表'
}


function normalizeText(value) {
  return String(value || '').toLowerCase().trim()
}

function matchesSearchFilters(row) {
  const keyword = normalizeText(searchFilters.keyword)
  const status = searchFilters.status
  const category = searchFilters.category
  const staffId = searchFilters.staffId
  const startDate = searchFilters.startDate
  const endDate = searchFilters.endDate

  if (status !== '全部' && row.status !== status) return false
  if (category !== '全部' && row.category !== category) return false

  if (staffId !== '全部') {
    const assigned = (row.schedule_assignees || []).some(item => item.staff_id === staffId && !item.deleted_at)
    if (!assigned) return false
  }

  if (startDate && row.start_date < startDate) return false
  if (endDate && row.start_date > endDate) return false

  if (keyword) {
    const haystack = normalizeText([
      row.title,
      row.description,
      row.category,
      row.schedule_type,
      row.sub_type,
      row.sub_type_note,
      row.customer_name,
      row.location_name,
      row.address,
      getAssigneeNames(row)
    ].join(' '))
    if (!haystack.includes(keyword)) return false
  }

  return true
}

function getSearchResults() {
  return schedules.filter(row => matchesSearchFilters(row))
}

function buildOptionList(items, selected) {
  return items.map(item => `<option value="${item}" ${item === selected ? 'selected' : ''}>${item}</option>`).join('')
}

function buildStaffSearchOptions() {
  return `<option value="全部" ${searchFilters.staffId === '全部' ? 'selected' : ''}>全部人員</option>` +
    staffList.map(staff => `<option value="${staff.staff_id}" ${searchFilters.staffId === staff.staff_id ? 'selected' : ''}>${staff.name}｜${staff.department_name}</option>`).join('')
}


function renderSearchResultList(rows, emptyText) {
  if (!rows.length) return `<div class="empty-state">${emptyText}</div>`

  return `
    <div class="search-result-list">
      ${rows.map(row => `
        <div class="search-result-row ${row.status === '已完成' ? 'is-completed' : ''} ${row.status === '取消' ? 'is-cancelled' : ''}">
          <div class="search-result-date">
            <strong>${escapeHtml(row.start_date || '-')}</strong>
            <span>${escapeHtml(formatTime(row))}</span>
          </div>

          <div class="search-result-main">
            <div class="search-result-title">${escapeHtml(row.schedule_type || row.category)}｜${escapeHtml(row.title || '-')}</div>
            <div class="search-result-meta">
              ${escapeHtml(row.status || '-')}｜${escapeHtml(getAssigneeNames(row))}
              ${row.customer_name ? '｜' + escapeHtml(row.customer_name) : ''}
              ${row.location_name ? '｜' + escapeHtml(row.location_name) : ''}${row.sub_type ? '｜附加：' + escapeHtml(row.sub_type) : ''}
            </div>
          </div>

          <div class="search-result-action">
            <button class="small-secondary-btn" data-view-schedule="${row.schedule_id}">查看</button>
          </div>
        </div>
      `).join('')}
    </div>
  `
}

function renderSearchPage() {
  const results = getSearchResults()
  const statusOptions = buildOptionList(['全部', '未完成', '已完成', '取消'], searchFilters.status)
  const categoryOptions = buildOptionList(['全部', ...formCategories], searchFilters.category)

  return `
    <div class="page-toolbar">
      <div>
        <h3>行程搜尋</h3>
        <p class="muted">搜尋已完成、取消與未完成行程；列表先簡潔顯示，需要完整內容再點查看。</p>
      </div>
      <div class="toolbar-actions">
        <button class="secondary-btn" id="resetSearchBtn">清除條件</button>
        <button class="secondary-btn" id="refreshBtn">重新整理</button>
      </div>
    </div>

    ${renderReadStatus()}

    <form id="searchForm" class="search-panel search-panel-simple">
      <label class="search-keyword">
        關鍵字
        <input name="keyword" value="${escapeHtml(searchFilters.keyword)}" placeholder="搜尋標題、客戶、地點、備註、人員">
      </label>

      <div class="search-row">
        <label>
          狀態
          <select name="status">${statusOptions}</select>
        </label>

        <label>
          類別
          <select name="category">${categoryOptions}</select>
        </label>

        <label>
          執行者
          <select name="staffId">${buildStaffSearchOptions()}</select>
        </label>
      </div>

      <div class="search-row date-range-row">
        <label>
          起日
          <input name="startDate" type="date" value="${searchFilters.startDate}">
        </label>

        <span class="date-range-separator">至</span>

        <label>
          迄日
          <input name="endDate" type="date" value="${searchFilters.endDate}">
        </label>

        <button type="submit" class="primary-btn">搜尋</button>
      </div>
    </form>

    <div class="summary-grid search-summary">
      <div class="summary-card">
        <strong>${results.length}</strong>
        <span>搜尋結果</span>
      </div>
      <div class="summary-card">
        <strong>${results.filter(row => row.status === '已完成').length}</strong>
        <span>已完成</span>
      </div>
      <div class="summary-card">
        <strong>${results.filter(row => row.status === '取消').length}</strong>
        <span>取消</span>
      </div>
    </div>

    ${renderSearchResultList(results, '沒有符合條件的行程。')}
  `
}


function matchesAuditFilters(row) {
  const keyword = normalizeText(auditFilters.keyword)
  const actionType = auditFilters.actionType
  const startDate = auditFilters.startDate
  const endDate = auditFilters.endDate
  const createdDate = row.created_at ? row.created_at.slice(0, 10) : ''

  if (actionType !== '全部' && row.action_type !== actionType) return false
  if (startDate && createdDate < startDate) return false
  if (endDate && createdDate > endDate) return false

  if (keyword) {
    const haystack = normalizeText([
      row.operated_by_name,
      row.action_type,
      row.source_type,
      row.note,
      row.source_id
    ].join(' '))
    if (!haystack.includes(keyword)) return false
  }

  return true
}

function formatDateTime(value) {
  if (!value) return '-'
  const date = new Date(value)
  if (Number.isNaN(date.getTime())) return value
  return date.toLocaleString('zh-TW', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false
  })
}

function getAuditActionTypes() {
  const types = [...new Set(auditLogs.map(row => row.action_type).filter(Boolean))]
  return ['全部', ...types]
}

function renderAuditPage() {
  const results = auditLogs.filter(row => matchesAuditFilters(row))
  const actionOptions = getAuditActionTypes().map(item => `<option value="${item}" ${auditFilters.actionType === item ? 'selected' : ''}>${item}</option>`).join('')

  return `
    <div class="page-toolbar">
      <div>
        <h3>異動紀錄</h3>
        <p class="muted">查詢新增、修改、完成、取消、紀錄單、回診與執行者異動紀錄。</p>
      </div>
      <div class="toolbar-actions">
        <button class="secondary-btn" id="resetAuditBtn">清除條件</button>
        <button class="secondary-btn" id="refreshBtn">重新整理</button>
      </div>
    </div>

    ${auditLoading ? '<div class="notice">正在讀取異動紀錄...</div>' : ''}
    ${auditError ? `<div class="error-card">讀取異動紀錄失敗：${escapeHtml(auditError)}</div>` : ''}

    <form id="auditForm" class="search-panel search-panel-simple">
      <label class="search-keyword">
        關鍵字
        <input name="keyword" value="${escapeHtml(auditFilters.keyword)}" placeholder="搜尋操作人、動作、備註">
      </label>

      <div class="search-row date-range-row audit-filter-row">
        <label>
          動作類型
          <select name="actionType">${actionOptions}</select>
        </label>

        <label>
          起日
          <input name="startDate" type="date" value="${auditFilters.startDate}">
        </label>

        <label>
          迄日
          <input name="endDate" type="date" value="${auditFilters.endDate}">
        </label>

        <button type="submit" class="primary-btn">搜尋</button>
      </div>
    </form>

    <div class="summary-grid search-summary">
      <div class="summary-card">
        <strong>${results.length}</strong>
        <span>異動筆數</span>
      </div>
      <div class="summary-card">
        <strong>${results.filter(row => row.action_type === '取消').length}</strong>
        <span>取消</span>
      </div>
      <div class="summary-card">
        <strong>${results.filter(row => String(row.action_type || '').includes('修改')).length}</strong>
        <span>修改類</span>
      </div>
    </div>

    ${renderAuditList(results)}
  `
}


function getAuditSourceLabel(row) {
  if (!row) return '-'

  if (row.source_type === 'schedule' && row.source_id) {
    const schedule = schedules.find(item => item.schedule_id === row.source_id)
    if (schedule) {
      const type = schedule.schedule_type || schedule.category || '行程'
      const title = schedule.title || '-'
      const date = schedule.start_date || '-'
      const status = schedule.status || '-'
      return `${type}｜${title}｜${date}｜${status}`
    }
  }

  if (row.source_type === 'service_record' && row.source_id) {
    const schedule = schedules.find(item => item.schedule_id === row.source_id)
    if (schedule) {
      return `服務紀錄單｜${schedule.schedule_type || schedule.category || '行程'}｜${schedule.title || '-'}｜${schedule.start_date || '-'}`
    }
  }

  return `${row.source_type || '-'}｜${row.source_id || '-'}`
}


function renderAuditList(rows) {
  if (!rows.length) return `<div class="empty-state">沒有符合條件的異動紀錄。</div>`

  return `
    <div class="audit-list">
      ${rows.map(row => `
        <div class="audit-row">
          <div class="audit-time">${escapeHtml(formatDateTime(row.created_at))}</div>
          <div class="audit-main">
            <div class="audit-title">
              <span class="audit-action">${escapeHtml(row.action_type || '-')}</span>
              <strong>${escapeHtml(row.operated_by_name || '-')}</strong>
            </div>
            <div class="audit-note">${escapeHtml(row.note || '-')}</div>
            <div class="audit-meta audit-source"><span>異動行程：</span>${escapeHtml(getAuditSourceLabel(row))}</div>
          </div>
        </div>
      `).join('')}
    </div>
  `
}


function renderPageContent() {
  if (currentPage === 'personalSchedule') return renderPersonalSchedule()
  if (currentPage === 'personalTodo') return renderPersonalTodo()
  if (currentPage === 'scheduleOverview') return renderScheduleOverview()
  if (currentPage === 'search') return renderSearchPage()
  if (currentPage === 'serviceRecord') return renderServiceRecordDashboard()
  if (currentPage === 'recordSubmit') return renderRecordSubmit()
  if (currentPage === 'audit') return renderAuditPage()
  if (currentPage === 'users') return renderUsersPage()

  return `
    <h3>${getPageTitle()}</h3>
    <p>此頁面目前為權限測試佔位頁，正式功能會在下一階段逐步加入。</p>
  `
}

function renderToolbar(title) {
  return `
    <div class="page-toolbar">
      <div>
        <h3>${title}</h3>
        <p class="muted">V002-1E-4：卡片、證件欄位、提醒標籤與 LOGO。</p>
      </div>
      <div class="toolbar-actions">
        <button class="primary-btn" id="addScheduleBtn">${currentPage === 'personalTodo' ? '新增一般待辦' : '新增行程'}</button>
        <button class="secondary-btn" id="refreshBtn">重新整理</button>
      </div>
    </div>
  `
}

function renderPersonalSchedule() {
  const myRows = schedules.filter(row => isActivePersonalSchedule(row) && isMine(row))
  const today = todayString()
  const todayRows = myRows.filter(row => row.start_date === today && row.status !== '已完成' && row.status !== '取消')

  return `
    ${renderToolbar('個人行程表')}
    ${renderReadStatus()}
    ${renderPersonalReminderArea()}
    <div class="summary-grid">
      <div class="summary-card">
        <strong>${todayRows.length}</strong>
        <span>今日待處理</span>
      </div>
      <div class="summary-card">
        <strong>${myRows.length}</strong>
        <span>個人行程總數</span>
      </div>
    </div>
    ${renderScheduleList(myRows, '目前沒有個人行程。', true)}
  `
}

function renderPersonalTodo() {
  const myRows = schedules.filter(row => isActivePersonalSchedule(row) && isMine(row) && ['一般記事', '待辦事項', '請假 / 會議 / 活動 / 外訓'].includes(row.category))
  return `
    ${renderToolbar('個人一般待辦')}
    ${renderReadStatus()}
    ${renderScheduleList(myRows, '目前沒有一般記事或待辦事項。', true)}
  `
}


function getMonday(date) {
  const d = new Date(date)
  const day = d.getDay()
  const diff = day === 0 ? -6 : 1 - day
  d.setDate(d.getDate() + diff)
  d.setHours(0, 0, 0, 0)
  return d
}

function addDays(date, days) {
  const d = new Date(date)
  d.setDate(d.getDate() + days)
  return d
}

function toDateKey(date) {
  const y = date.getFullYear()
  const m = String(date.getMonth() + 1).padStart(2, '0')
  const d = String(date.getDate()).padStart(2, '0')
  return `${y}-${m}-${d}`
}

function getWeekDates(offset = 0) {
  const monday = getMonday(new Date())
  monday.setDate(monday.getDate() + offset * 7)
  return Array.from({ length: 7 }, (_, i) => addDays(monday, i))
}

function getWeekLabel(weekDates) {
  if (!weekDates.length) return ''
  return `${toDateKey(weekDates[0])} ～ ${toDateKey(weekDates[6])}`
}

function getOverviewStaffRows() {
  const role = currentProfile?.role
  if (['管理員', '主管', '行政 / 海外'].includes(role)) return staffList
  const visibleStaffIds = new Set()
  schedules.forEach(row => {
    if (isMine(row)) {
      ;(row.schedule_assignees || []).forEach(item => {
        if (!item.deleted_at) visibleStaffIds.add(item.staff_id)
      })
    }
  })
  if (currentProfile?.staff_id) visibleStaffIds.add(currentProfile.staff_id)
  return staffList.filter(staff => visibleStaffIds.has(staff.staff_id))
}

function getSchedulesForStaffDate(staffId, dateKey) {
  return schedules.filter(row => {
    if (!isVisibleSchedule(row)) return false
    if (row.start_date !== dateKey) return false
    return (row.schedule_assignees || []).some(item => item.staff_id === staffId && !item.deleted_at)
  })
}

function renderWeekScheduleCard(row) {
  const contentPreview = getFirstTwoLines(row.description)
  return `
    <button type="button" class="week-schedule-card ${row.status === '已完成' ? 'is-completed' : ''}" data-view-schedule="${row.schedule_id}">
      <span class="week-card-time">${escapeHtml(formatTime(row))}</span>
      <strong>${escapeHtml(row.schedule_type || row.category)}｜${escapeHtml(row.title || '-')}</strong>
      ${contentPreview ? `<span class="week-card-preview">${escapeHtml(contentPreview).replaceAll('\n', ' / ')}</span>` : ''}
      ${row.sub_type ? `<span class="week-card-extra">附加：${escapeHtml(row.sub_type)}</span>` : ''}
    </button>
  `
}


function renderScheduleOverview() {
  const weekDates = getWeekDates(overviewWeekOffset)
  const staffRows = getOverviewStaffRows()
  const todayKey = todayString()

  return `
    <div class="page-toolbar">
      <div>
        <h3>行程總覽</h3>
        <p class="muted">人員 × 週一～週日｜${getWeekLabel(weekDates)}</p>
      </div>
      <div class="toolbar-actions">
        <button class="secondary-btn" id="prevWeekBtn">上一週</button>
        <button class="secondary-btn" id="thisWeekBtn">本週</button>
        <button class="secondary-btn" id="nextWeekBtn">下一週</button>
        <button class="primary-btn" id="addScheduleBtn">新增行程</button>
        <button class="secondary-btn" id="refreshBtn">重新整理</button>
      </div>
    </div>

    ${renderReadStatus()}

    <div class="week-overview-scroll">
      <table class="week-overview-table">
        <thead>
          <tr>
            <th class="staff-col">人員</th>
            ${weekDates.map(date => {
              const key = toDateKey(date)
              const weekName = ['週日', '週一', '週二', '週三', '週四', '週五', '週六'][date.getDay()]
              return `<th class="${key === todayKey ? 'is-today' : ''} ${isTaiwanHoliday(date) ? 'is-holiday' : ''}">
                <span>${weekName}</span>
                <strong>${key.slice(5)}</strong>
                ${renderHolidayLabels(key)}
              </th>`
            }).join('')}
          </tr>
        </thead>
        <tbody>
          ${staffRows.map(staff => `
            <tr>
              <th class="staff-name-cell">
                <strong>${escapeHtml(staff.name)}</strong>
                <span>${escapeHtml(staff.department_name || '')}</span>
              </th>
              ${weekDates.map(date => {
                const key = toDateKey(date)
                const dayRows = getSchedulesForStaffDate(staff.staff_id, key)
                return `<td class="week-day-cell ${key === todayKey ? 'is-today' : ''} ${isTaiwanHoliday(date) ? 'is-holiday' : ''}" data-week-date="${key}" data-staff-id="${staff.staff_id}">
                  ${dayRows.length ? dayRows.map(renderWeekScheduleCard).join('') : '<span class="week-empty">—</span>'}
                </td>`
              }).join('')}
            </tr>
          `).join('')}
        </tbody>
      </table>
    </div>

    ${!staffRows.length ? '<div class="empty-state">目前沒有可顯示的人員。</div>' : ''}
  `
}


function renderReadStatus() {
  if (loadingSchedules) return `<div class="notice">正在讀取行程資料...</div>`
  if (schedulesError) return `<div class="error-card">讀取行程失敗：${schedulesError}</div>`
  return ''
}

function renderScheduleList(rows, emptyText, hideCategoryMeta = false) {
  if (!rows.length) return `<div class="empty-state">${emptyText}</div>`

  return `
    <div class="schedule-list">
      ${rows.map(row => {
        const contentPreview = getFirstTwoLines(row.description)
        const reminders = getReminderTokens(row)
        return `
          <div class="schedule-card ${row.status === '已完成' ? 'is-completed' : ''} ${row.status === '取消' ? 'is-cancelled' : ''}">
            <div class="schedule-card-main">
              <div class="schedule-date">${formatDate(row.start_date)}${row.end_date && row.end_date !== row.start_date ? ' ～ ' + formatDate(row.end_date) : ''}｜${formatTime(row)}</div>
              <div class="schedule-title"><span class="schedule-type-prefix">${escapeHtml(row.schedule_type || row.category)}</span>｜${escapeHtml(row.title)}</div>
              ${contentPreview ? `<div class="schedule-content-preview">${escapeHtml(contentPreview).replaceAll('\n', '<br>')}</div>` : ''}
              ${hideCategoryMeta ? '' : `<div class="schedule-meta">${escapeHtml(row.category)}</div>`}
              ${row.sub_type ? `<div class="extra-schedule-chip">附加行程：${escapeHtml(row.sub_type)}</div>` : ''}
              <div class="schedule-meta">執行者：${escapeHtml(getAssigneeNames(row))}</div>
              ${row.customer_name ? `<div class="schedule-meta">區域 / 客戶：${escapeHtml(row.customer_name)}</div>` : ''}
              ${row.location_name ? `<div class="schedule-meta">地點：${escapeHtml(row.location_name)}</div>` : ''}
              ${reminders.length ? `<div class="reminder-tags">${reminders.map(item => `<span>${escapeHtml(item)}</span>`).join('')}</div>` : ''}
              ${row.need_service_record ? `<div class="service-record-hint ${row.service_record_submitted_date ? 'is-submitted' : 'is-missing'}">${row.service_record_submitted_date ? '服務紀錄單已交' : '服務紀錄單未填日期'}</div>` : ''}
            </div>
            <div class="schedule-card-actions">
              <span class="status-pill">${row.status}</span>
              <button class="small-secondary-btn" data-view-schedule="${row.schedule_id}">查看</button>\n              ${row.need_service_record ? `<button class="small-record-btn" data-record-schedule="${row.schedule_id}">紀錄單</button>` : ``}
            </div>
          </div>
        `
      }).join('')}
    </div>
  `
}


function getServiceRecordSchedule(record) {
  if (!record || !record.schedule_id) return null
  return schedules.find(row => row.schedule_id === record.schedule_id) || null
}

function getServiceRecordStatus(record) {
  if (record.submitted || record.submitted_date) return '已繳交'

  const scheduleDate = record.schedule_date
  if (!scheduleDate) return '未繳交'

  const diffMs = new Date(todayString()) - new Date(scheduleDate)
  const diffDays = Math.floor(diffMs / 86400000)

  if (diffDays >= 14) return '超過2週'
  return '未繳交'
}

function getServiceRecordDays(record) {
  if (!record.schedule_date) return '-'
  const diffMs = new Date(todayString()) - new Date(record.schedule_date)
  const diffDays = Math.max(0, Math.floor(diffMs / 86400000))
  return `${diffDays} 天`
}

function matchesServiceRecordFilters(record, onlyMine = false) {
  if (onlyMine && currentProfile?.staff_id && record.staff_id !== currentProfile.staff_id) return false

  const status = getServiceRecordStatus(record)
  if (serviceRecordFilters.status !== '全部' && status !== serviceRecordFilters.status) return false

  if (serviceRecordFilters.staffId !== '全部' && record.staff_id !== serviceRecordFilters.staffId) return false

  if (serviceRecordFilters.startDate && record.schedule_date < serviceRecordFilters.startDate) return false
  if (serviceRecordFilters.endDate && record.schedule_date > serviceRecordFilters.endDate) return false

  return true
}

function renderServiceRecordFilterForm(onlyMine = false) {
  const statusOptions = ['全部', '未繳交', '超過2週', '已繳交']
    .map(item => `<option value="${item}" ${serviceRecordFilters.status === item ? 'selected' : ''}>${item}</option>`)
    .join('')

  const staffOptions = onlyMine
    ? ''
    : `<label>
        翻譯 / 人員
        <select name="staffId">
          <option value="全部" ${serviceRecordFilters.staffId === '全部' ? 'selected' : ''}>全部人員</option>
          ${staffList.map(staff => `<option value="${staff.staff_id}" ${serviceRecordFilters.staffId === staff.staff_id ? 'selected' : ''}>${staff.name}｜${staff.department_name}</option>`).join('')}
        </select>
      </label>`

  return `
    <form id="serviceRecordFilterForm" class="service-record-filter">
      <label>
        狀態
        <select name="status">${statusOptions}</select>
      </label>

      ${staffOptions}

      <label>
        起日
        <input name="startDate" type="date" value="${serviceRecordFilters.startDate}">
      </label>

      <label>
        迄日
        <input name="endDate" type="date" value="${serviceRecordFilters.endDate}">
      </label>

      <button type="submit" class="primary-btn">篩選</button>
    </form>
  `
}

function renderServiceRecordSummary(records) {
  return `
    <div class="summary-grid service-record-summary">
      <div class="summary-card">
        <strong>${records.length}</strong>
        <span>紀錄單總數</span>
      </div>
      <div class="summary-card">
        <strong>${records.filter(row => getServiceRecordStatus(row) === '未繳交').length}</strong>
        <span>未繳交</span>
      </div>
      <div class="summary-card">
        <strong>${records.filter(row => getServiceRecordStatus(row) === '超過2週').length}</strong>
        <span>超過2週</span>
      </div>
      <div class="summary-card">
        <strong>${records.filter(row => getServiceRecordStatus(row) === '已繳交').length}</strong>
        <span>已繳交</span>
      </div>
    </div>
  `
}

function renderServiceRecordList(records, emptyText) {
  if (!records.length) return `<div class="empty-state">${emptyText}</div>`

  return `
    <div class="service-record-list">
      ${records.map(record => {
        const schedule = getServiceRecordSchedule(record)
        const status = getServiceRecordStatus(record)
        const scheduleType = record.schedule_type || schedule?.schedule_type || '-'
        const title = record.title || schedule?.title || '-'
        const location = record.location_name || schedule?.location_name || schedule?.customer_name || '-'

        return `
          <div class="service-record-row status-${status}">
            <div class="service-record-date">
              <strong>${escapeHtml(record.schedule_date || '-')}</strong>
              <span>${escapeHtml(getServiceRecordDays(record))}</span>
            </div>

            <div class="service-record-main">
              <div class="service-record-title">${escapeHtml(scheduleType)}｜${escapeHtml(title)}</div>
              <div class="service-record-meta">
                ${escapeHtml(record.staff_name || '-')}｜${escapeHtml(record.department_name || '-')}｜${escapeHtml(location)}
              </div>
            </div>

            <div class="service-record-status-wrap">
              <span class="record-status-pill">${escapeHtml(status)}</span>
              ${record.submitted_date ? `<span class="record-submit-date">${escapeHtml(record.submitted_date)}</span>` : ''}
            </div>

            <div class="service-record-action">
              ${record.schedule_id ? `<button class="small-record-btn" data-record-schedule="${record.schedule_id}">繳交狀況</button>` : ''}
              ${record.schedule_id ? `<button class="small-secondary-btn" data-view-schedule="${record.schedule_id}">查看</button>` : ''}
            </div>
          </div>
        `
      }).join('')}
    </div>
  `
}

function renderServiceRecordDashboard() {
  const records = serviceRecords.filter(record => matchesServiceRecordFilters(record, false))

  return `
    <div class="page-toolbar">
      <div>
        <h3>服務紀錄單</h3>
        <p class="muted">管理員 / 主管查看全部服務紀錄單繳交狀況。</p>
      </div>
      <div class="toolbar-actions">
        <button class="secondary-btn" id="resetServiceRecordFilterBtn">清除條件</button>
        <button class="secondary-btn" id="refreshBtn">重新整理</button>
      </div>
    </div>

    ${serviceRecordsLoading ? '<div class="notice">正在讀取服務紀錄單...</div>' : ''}
    ${serviceRecordsError ? `<div class="error-card">讀取服務紀錄單失敗：${escapeHtml(serviceRecordsError)}</div>` : ''}

    ${renderServiceRecordFilterForm(false)}
    ${renderServiceRecordSummary(records)}
    ${renderServiceRecordList(records, '目前沒有符合條件的服務紀錄單。')}
  `
}


function renderRecordSubmit() {
  const records = serviceRecords.filter(record => matchesServiceRecordFilters(record, true))

  return `
    <div class="page-toolbar">
      <div>
        <h3>紀錄單繳交</h3>
        <p class="muted">翻譯查看自己的服務紀錄單繳交狀況。</p>
      </div>
      <div class="toolbar-actions">
        <button class="secondary-btn" id="resetServiceRecordFilterBtn">清除條件</button>
        <button class="secondary-btn" id="refreshBtn">重新整理</button>
      </div>
    </div>

    ${serviceRecordsLoading ? '<div class="notice">正在讀取紀錄單繳交狀況...</div>' : ''}
    ${serviceRecordsError ? `<div class="error-card">讀取紀錄單失敗：${escapeHtml(serviceRecordsError)}</div>` : ''}

    ${renderServiceRecordFilterForm(true)}
    ${renderServiceRecordSummary(records)}
    ${renderServiceRecordList(records, '目前沒有需要繳交的服務紀錄單。')}
  `
}

function renderUsersPage() {
  return `
    <h3>人員 / 帳號</h3>
    <div class="notice">
      權限規則：管理員可管理全部帳號；主管、行政、翻譯、外務 / 宿管人員 / 會計、一般職員只能查看與修改自己的帳號基本資料，不能刪除、停用或啟用帳號。
    </div>
    <div class="empty-state">
      <strong>目前登入帳號</strong>
      <p>${currentProfile.email}</p>
    </div>
  `
}

function openScheduleDetail(scheduleId) {
  const row = schedules.find(item => item.schedule_id === scheduleId)
  if (!row) return

  const permissionNote = canModifySchedule(row)
    ? '您可以管理此行程，包含修改內容與執行者。'
    : '此行程由他人指派，您只能查看與完成，不能修改、取消或刪除。'

  const modal = document.createElement('div')
  modal.className = 'modal-backdrop'
  modal.innerHTML = `
    <div class="modal-panel detail-panel">
      <div class="modal-header">
        <h3>查看行程</h3>
        <button class="icon-btn" id="closeDetailBtn" type="button">×</button>
      </div>

      <div class="detail-grid">
        <div><span>狀態</span><strong>${escapeHtml(row.status)}</strong></div>
        <div><span>日期</span><strong>${escapeHtml(row.start_date)}${row.end_date && row.end_date !== row.start_date ? ' ～ ' + escapeHtml(row.end_date) : ''}</strong></div>
        <div><span>時間</span><strong>${escapeHtml(formatTime(row))}</strong></div>
        <div><span>類別</span><strong>${escapeHtml(row.category)}</strong></div>
        <div><span>行程類型</span><strong>${escapeHtml(row.schedule_type || '-')}</strong></div>
        <div><span>附加 / 待辦 / 代理</span><strong>${escapeHtml(row.sub_type || '-')}</strong></div>
        <div><span>執行者</span><strong>${escapeHtml(getAssigneeNames(row))}</strong></div>
        <div><span>公務車</span><strong>${escapeHtml(row.car_no || '-')}</strong></div>
        <div class="span-2"><span>標題 / 辦理內容</span><strong>${escapeHtml(row.title)}</strong></div>
        <div class="span-2"><span>區域 / 客戶</span><strong>${escapeHtml(row.customer_name || '-')}</strong></div>
        <div class="span-2"><span>地點</span><strong>${escapeHtml(row.location_name || '-')}</strong></div>
        <div class="span-2"><span>地址</span><strong>${escapeHtml(row.address || '-')}</strong></div>
        <div class="span-2"><span>內容</span><strong>${escapeHtml(row.description || '-')}</strong></div>
        <div class="span-2"><span>備註 / 提醒 / 證件</span><strong>${escapeHtml(row.sub_type_note || '-')}</strong></div>
        <div class="span-2"><span>服務紀錄單繳交狀況</span><strong>${row.need_service_record ? (row.service_record_submitted_date ? '已繳交：' + row.service_record_submitted_date : '需繳交，尚未繳交') : '不需繳交'}</strong></div>
      </div>

      <div class="notice">${permissionNote}</div>

      <div class="modal-actions">
        <button type="button" class="secondary-btn" id="closeDetailBtn2">關閉</button>
        ${row.schedule_type === '醫療' && isMine(row) && row.status !== '取消' ? `<button type="button" class="secondary-btn" id="detailMedicalFollowBtn">回診資訊</button>` : ''}
        ${canModifySchedule(row) && row.status !== '取消' ? `<button type="button" class="secondary-btn" id="detailEditBtn">修改行程</button>` : ''}
        ${canCompleteSchedule(row) ? `<button type="button" class="primary-btn" id="detailCompleteBtn">已完成</button>` : ''}
        ${canCancelSchedule(row) ? `<button type="button" class="danger-btn" id="detailCancelBtn">取消行程</button>` : ''}
      </div>
    </div>
  `

  document.body.appendChild(modal)
  document.querySelector('#closeDetailBtn').addEventListener('click', () => modal.remove())
  document.querySelector('#closeDetailBtn2').addEventListener('click', () => modal.remove())

  const medicalFollowBtn = document.querySelector('#detailMedicalFollowBtn')
  if (medicalFollowBtn) {
    medicalFollowBtn.addEventListener('click', () => {
      modal.remove()
      openMedicalFollowModal(scheduleId)
    })
  }

  const editBtn = document.querySelector('#detailEditBtn')
  if (editBtn) {
    editBtn.addEventListener('click', () => {
      modal.remove()
      openEditScheduleModal(scheduleId)
    })
  }

  const completeBtn = document.querySelector('#detailCompleteBtn')
  if (completeBtn) {
    completeBtn.addEventListener('click', async () => {
      modal.remove()
      await completeSchedule(scheduleId)
    })
  }

  const cancelBtn = document.querySelector('#detailCancelBtn')
  if (cancelBtn) {
    cancelBtn.addEventListener('click', async () => {
      modal.remove()
      openCancelModal(scheduleId)
    })
  }
}

function editStaffOptionsHtml(row) {
  const selectedIds = new Set(getAssigneeIds(row))
  return staffList.map(staff => `
    <label class="check-row">
      <input type="checkbox" name="edit_executor" value="${staff.staff_id}" ${selectedIds.has(staff.staff_id) ? 'checked' : ''}>
      <span>${staff.name}｜${staff.department_name}｜${staff.position}</span>
    </label>
  `).join('')
}

function staffOptionsHtml(defaultStaffId = '') {
  return staffList.map(staff => `
    <label class="check-row">
      <input type="checkbox" name="executor" value="${staff.staff_id}" ${staff.staff_id === defaultStaffId ? 'checked' : ''}>
      <span>${staff.name}｜${staff.department_name}｜${staff.position}</span>
    </label>
  `).join('')
}

function staffSelectOptionsHtml() {
  return `<option value="">未指定</option>` + staffList.map(staff => `
    <option value="${staff.staff_id}">${staff.name}｜${staff.department_name}</option>
  `).join('')
}

function hourOptionsHtml(defaultValue = '09') {
  return Array.from({ length: 24 }, (_, i) => {
    const value = String(i).padStart(2, '0')
    return `<option value="${value}" ${value === defaultValue ? 'selected' : ''}>${value}</option>`
  }).join('')
}

function minuteOptionsHtml(defaultValue = '00') {
  return Array.from({ length: 12 }, (_, i) => {
    const value = String(i * 5).padStart(2, '0')
    return `<option value="${value}" ${value === defaultValue ? 'selected' : ''}>${value}</option>`
  }).join('')
}

function getAvailableFormCategories() {
  if (currentPage === 'personalTodo') return ['一般記事', '待辦事項', '請假 / 會議 / 活動 / 外訓']
  return formCategories
}

function serviceTypeOptionsHtml(includeEmpty = false) {
  const empty = includeEmpty ? '<option value="">無</option>' : ''
  return empty + serviceScheduleTypes.map(type => `<option value="${type}">${type}</option>`).join('')
}

function optionHtml(items, selectedValue = '', includeEmpty = false) {
  const empty = includeEmpty ? `<option value="">無</option>` : ''
  return empty + items.map(item => `<option value="${item}" ${item === selectedValue ? 'selected' : ''}>${item}</option>`).join('')
}

function timeTypeOptionsHtml(selectedValue = '不指定') {
  return ['不指定', '上午', '下午'].map(item => `<option value="${item}" ${item === selectedValue ? 'selected' : ''}>${item}</option>`).join('')
}


function compactTimeSelectHtml(prefix, defaultHour = '09', defaultMinute = '00') {
  return `
    <div class="compact-time-row">
      <select name="${prefix}_time_type">
        <option value="不指定">不指定</option>
        <option value="上午">上午</option>
        <option value="下午">下午</option>
        <option value="指定時間">指定時間</option>
      </select>
      <select name="${prefix}_hour">${hourOptionsHtml(defaultHour)}</select>
      <select name="${prefix}_minute">${minuteOptionsHtml(defaultMinute)}</select>
    </div>
  `
}

function openScheduleModal() {
  const defaultStaffId = currentProfile.staff_id || ''
  const availableFormCategories = getAvailableFormCategories()
  const formCategoryOptions = availableFormCategories.map(category => `<option value="${category}">${category}</option>`).join('')
  const todoOptions = todoItems.map(item => `<option value="${item}">${item}</option>`).join('')
  const leaveOptions = leaveMeetingTypes.map(item => `<option value="${item}">${item}</option>`).join('')
  const carSelectOptions = carOptions.map(item => `<option value="${item}">${item}</option>`).join('')
  const weekdayChecks = weekdays.map(([value, label]) => `
    <label class="inline-check"><input type="checkbox" name="repeat_weekdays" value="${value}">${label}</label>
  `).join('')
  const documentChecks = documentOptions.map(item => `
    <label class="inline-check"><input type="checkbox" name="document_items" value="${item}">${item}</label>
  `).join('')

  const modal = document.createElement('div')
  modal.className = 'modal-backdrop'
  modal.innerHTML = `
    <div class="modal-panel">
      <div class="modal-header">
        <h3>${currentPage === 'personalTodo' ? '新增一般待辦' : '新增行程'}</h3>
        <button class="icon-btn" id="closeModalBtn" type="button">×</button>
      </div>

      <form id="scheduleForm" class="form-grid">
        <label>
          執行狀態
          <input value="未完成" disabled>
        </label>

        <label>
          類別
          <select name="category" id="categorySelect">
            ${formCategoryOptions}
          </select>
        </label>

        <div class="span-2 block-group">
          <div class="group-title">日期與週期</div>

          <div class="form-grid inner-grid">
            <label>
              行程模式
              <select name="repeat_mode" id="repeatModeSelect">
                <option value="單日">單日</option>
                <option value="連續日期">連續日期</option>
                <option value="每週重複">每週重複</option>
                <option value="每月重複">每月重複</option>
              </select>
            </label>

            <label>
              開始日期
              <input name="start_date" type="date" required value="${todayString()}">
            </label>

            <label class="hidden" id="endDateBlock">
              結束日期
              <input name="end_date" type="date" value="${todayString()}">
            </label>

            <label class="hidden" id="monthlyDayBlock">
              每月幾號
              <select name="monthly_day">
                ${Array.from({ length: 31 }, (_, i) => `<option value="${i + 1}">${i + 1} 號</option>`).join('')}
              </select>
            </label>

            <div class="span-2 hidden" id="weekdayBlock">
              <div class="field-title">重複星期</div>
              <div class="inline-check-list">${weekdayChecks}</div>
            </div>
          </div>
        </div>

        <div class="span-2 block-group">
          <div class="group-title">時間</div>

          <div class="form-grid inner-grid">
            <label>
              時間類型
              <select name="time_type" id="timeTypeSelect">
                <option value="不指定">不指定</option>
                <option value="上午">上午</option>
                <option value="下午">下午</option>
              </select>
            </label>

            <div class="span-2 conditional-time hidden" id="timeRangeBlock">
              <div class="time-select-row">
                <label>
                  開始小時
                  <select name="start_hour">${hourOptionsHtml('09')}</select>
                </label>
                <label>
                  開始分鐘
                  <select name="start_minute">${minuteOptionsHtml('00')}</select>
                </label>
                <label>
                  結束小時
                  <select name="end_hour">${hourOptionsHtml('10')}</select>
                </label>
                <label>
                  結束分鐘
                  <select name="end_minute">${minuteOptionsHtml('00')}</select>
                </label>
              </div>
              <p class="field-hint">上午、下午、指定時間都可設定起訖時間；分鐘固定 5 分鐘為單位。</p>
            </div>
          </div>
        </div>

        <div class="span-2 form-section hidden service-grid service-top-grid" data-section="service-top">
          <label>
            行程類型
            <select name="schedule_type" id="serviceTypeSelect">
              ${serviceTypeOptionsHtml(false)}
            </select>
          </label>

          <div class="extra-schedule-box">
            <label>
              是否有附加行程
              <select name="has_extra_schedule" id="hasExtraScheduleSelect">
                <option value="否">否</option>
                <option value="是">是</option>
              </select>
            </label>
            <div id="extraScheduleBlock" class="hidden">
              <label>
                附加行程
                <select name="sub_type">
                  ${serviceTypeOptionsHtml(true)}
                </select>
              </label>
              <label>
                附加行程備註
                <input name="sub_type_note" placeholder="附加行程補充說明">
              </label>
            </div>
          </div>

          <div class="span-2 service-record-box">
            <div class="field-title">服務紀錄單</div>
            <label class="service-check">
              <input name="need_service_record" type="checkbox" id="needServiceRecordCheck">
              <span>需要服務紀錄單</span>
            </label>
            <label class="service-check">
              <input name="service_record_submitted_check" type="checkbox" id="serviceRecordSubmittedCheck">
              <span>已繳交</span>
            </label>
          </div>

          <label class="span-2">
            服務紀錄單繳交日期
            <input name="service_record_submitted_date" type="date">
          </label>
        </div>

        <div class="span-2 form-section hidden service-location-top" data-section="service-location">
          <label>
            區域 / 客戶名稱
            <input name="customer_name" placeholder="例如：客來喜">
          </label>

          <label>
            地點
            <input name="location_name" placeholder="例如：醫院、公司、宿舍">
          </label>

          <label class="span-2">
            地址
            <input name="address" placeholder="完整地址，可先空白">
          </label>
        </div>

        <div class="span-2 form-section" data-section="common-simple">
          <label>
            標題
            <input name="title" required placeholder="請輸入標題">
          </label>

          <label>
            內容
            <textarea name="description" rows="3" placeholder="請輸入內容"></textarea>
          </label>
        </div>

        <div class="span-2 form-section hidden" data-section="todo">
          <label>
            待辦項目
            <select name="todo_item">
              ${todoOptions}
            </select>
          </label>
          <p class="field-hint">待辦項目之後會放到「選項管理」維護。</p>
        </div>

        <div class="span-2 form-section hidden" data-section="leave-meeting">
          <label>
            類別細項
            <select name="leave_meeting_type">
              ${leaveOptions}
            </select>
          </label>

          <label>
            代理人
            <select name="proxy_staff_id" id="proxyStaffSelect">
              ${staffSelectOptionsHtml()}
            </select>
          </label>
        </div>

        <div class="span-2 form-section hidden service-grid" data-section="service">
          <div class="span-2 vehicle-doc-row">
            <label>
              公務車
              <select name="car_no">
                ${carSelectOptions}
              </select>
            </label>

            <div class="document-section">
            <label>
              是否有證件
              <select name="has_documents" id="hasDocumentsSelect">
                <option value="否">否</option>
                <option value="是">是</option>
              </select>
            </label>

            <div id="documentOptionsBlock" class="hidden">
              <div class="field-title">證件勾選</div>
              <div class="inline-check-list">${documentChecks}</div>
              <label>
                證件 / 文件備註
                <input name="document_note" placeholder="例如：文件內容、用印說明、其他證件">
              </label>
            </div>
          </div>

          </div>

          <div class="span-2 conditional-service hidden" data-service-extra="逃跑通知">
            <div class="group-title">逃跑三日通知</div>
            <div class="compact-grid">
              <label>第一日日期<input name="runaway_day1" type="date"></label>
              <label>第二日日期<input name="runaway_day2" type="date"></label>
              <label>第三日日期<input name="runaway_day3" type="date"></label>
            </div>
          </div>

          <div class="span-2 conditional-service hidden" data-service-extra="轉出追蹤">
            <div class="group-title">轉出提醒</div>
            <div class="compact-grid">
              <label>終止日<input name="transfer_end_date" type="date"></label>
              <label>轉出到期日<input name="transfer_due_date" type="date"></label>
            </div>
          </div>

          <div class="span-2 conditional-service hidden" data-service-extra="返台提醒">
            <div class="group-title">抵台提醒</div>
            <div class="compact-grid">
              <label>返台日期<input name="return_date" type="date"></label>
              <label>班機<input name="return_flight" placeholder="班機"></label>
              <label>
                抵台時間
                ${compactTimeSelectHtml('arrival', '09', '00')}
              </label>
            </div>
          </div>

          <div class="span-2 conditional-service hidden" data-service-extra="住變資訊">
            <div class="group-title">住變提醒</div>
            <div class="compact-grid">
              <label>住變日期<input name="housing_change_date" type="date"></label>
              <label>
                搬家時間
                ${compactTimeSelectHtml('housing_move', '09', '00')}
              </label>
              <label class="span-2">新地址 / 住變說明<input name="housing_note" placeholder="新地址或住變說明"></label>
            </div>
          </div>

          <div class="span-2 conditional-service hidden" data-service-extra="驗證提醒">
            <div class="group-title">驗證提醒</div>
            <div class="compact-grid">
              <label>最後工作日<input name="verify_last_work_date" type="date"></label>
              <label>驗證日期<input name="verify_date" type="date"></label>
              <label>離境日期<input name="verify_leave_date" type="date"></label>
            </div>
          </div>

        </div>

        <div class="span-2">
          <div class="field-title">執行者</div>
          <div class="checkbox-list">${staffOptionsHtml(defaultStaffId) || '<div class="empty-state">目前沒有可選人員。</div>'}</div>
        </div>

        <div class="modal-actions span-2">
          <button type="button" class="secondary-btn" id="cancelModalBtn">取消</button>
          <button type="submit" class="primary-btn">儲存</button>
        </div>
      </form>
    </div>
  `

  document.body.appendChild(modal)

  const categorySelect = document.querySelector('#categorySelect')
  const timeTypeSelect = document.querySelector('#timeTypeSelect')
  const repeatModeSelect = document.querySelector('#repeatModeSelect')
  const serviceTypeSelect = document.querySelector('#serviceTypeSelect')
  const hasDocumentsSelect = document.querySelector('#hasDocumentsSelect')

  function refreshFormSections() {
    const category = categorySelect.value
    document.querySelectorAll('.form-section').forEach(section => section.classList.add('hidden'))
    document.querySelector('[data-section="common-simple"]').classList.remove('hidden')

    if (category === '待辦事項') document.querySelector('[data-section="todo"]').classList.remove('hidden')
    if (category === '請假 / 會議 / 活動 / 外訓') document.querySelector('[data-section="leave-meeting"]').classList.remove('hidden')
    if (category === '服務行程') {
      const serviceTop = document.querySelector('[data-section="service-top"]')
      const serviceLocation = document.querySelector('[data-section="service-location"]')
      const serviceBlock = document.querySelector('[data-section="service"]')
      if (serviceTop) serviceTop.classList.remove('hidden')
      if (serviceLocation) serviceLocation.classList.remove('hidden')
      if (serviceBlock) serviceBlock.classList.remove('hidden')
    }
  }

  function refreshTimeBlock() {
    const showTime = ['上午', '下午'].includes(timeTypeSelect.value)
    document.querySelector('#timeRangeBlock').classList.toggle('hidden', !showTime)
  }

  function refreshRepeatBlocks() {
    const mode = repeatModeSelect.value
    document.querySelector('#endDateBlock').classList.toggle('hidden', mode === '單日')
    document.querySelector('#weekdayBlock').classList.toggle('hidden', mode !== '每週重複')
    document.querySelector('#monthlyDayBlock').classList.toggle('hidden', mode !== '每月重複')
  }

  function refreshServiceExtras() {
    const selected = serviceTypeSelect.value
    document.querySelectorAll('[data-service-extra]').forEach(block => {
      block.classList.toggle('hidden', block.dataset.serviceExtra !== selected)
    })

    if (selected === '收送簽文件') {
      hasDocumentsSelect.value = '是'
    }
    refreshDocumentsBlock()
  }

  function refreshDocumentsBlock() {
    document.querySelector('#documentOptionsBlock').classList.toggle('hidden', hasDocumentsSelect.value !== '是')
  }

  categorySelect.addEventListener('change', refreshFormSections)
  timeTypeSelect.addEventListener('change', refreshTimeBlock)
  repeatModeSelect.addEventListener('change', refreshRepeatBlocks)
  serviceTypeSelect.addEventListener('change', refreshServiceExtras)
  hasDocumentsSelect.addEventListener('change', refreshDocumentsBlock)

  const hasExtraScheduleSelect = document.querySelector('#hasExtraScheduleSelect')
  const extraScheduleBlock = document.querySelector('#extraScheduleBlock')

  function refreshExtraScheduleBlock() {
    if (!hasExtraScheduleSelect || !extraScheduleBlock) return
    extraScheduleBlock.classList.toggle('hidden', hasExtraScheduleSelect.value !== '是')
  }

  if (hasExtraScheduleSelect) hasExtraScheduleSelect.addEventListener('change', refreshExtraScheduleBlock)

  const needServiceRecordCheck = document.querySelector('#needServiceRecordCheck')
  const serviceRecordSubmittedCheck = document.querySelector('#serviceRecordSubmittedCheck')
  const submittedDateInput = document.querySelector('input[name="service_record_submitted_date"]')

  function refreshServiceRecordChecks() {
    if (!needServiceRecordCheck || !serviceRecordSubmittedCheck || !submittedDateInput) return
    if (!needServiceRecordCheck.checked) {
      serviceRecordSubmittedCheck.checked = false
      submittedDateInput.value = ''
      serviceRecordSubmittedCheck.disabled = true
      submittedDateInput.disabled = true
    } else {
      serviceRecordSubmittedCheck.disabled = false
      submittedDateInput.disabled = !serviceRecordSubmittedCheck.checked
      if (serviceRecordSubmittedCheck.checked && !submittedDateInput.value) submittedDateInput.value = todayString()
      if (!serviceRecordSubmittedCheck.checked) submittedDateInput.value = ''
    }
  }

  if (needServiceRecordCheck) needServiceRecordCheck.addEventListener('change', refreshServiceRecordChecks)
  if (serviceRecordSubmittedCheck) serviceRecordSubmittedCheck.addEventListener('change', refreshServiceRecordChecks)

  refreshServiceRecordChecks()

  refreshFormSections()
  refreshTimeBlock()
  refreshRepeatBlocks()
  refreshServiceExtras()
  refreshDocumentsBlock()
  refreshExtraScheduleBlock()

  document.querySelector('#closeModalBtn').addEventListener('click', () => modal.remove())
  document.querySelector('#cancelModalBtn').addEventListener('click', () => modal.remove())
  document.querySelector('#scheduleForm').addEventListener('submit', event => saveSchedule(event, modal))
}

function getTimeValue(form, prefix) {
  const timeType = form.get('time_type')
  if (!['上午', '下午'].includes(timeType)) return null
  const hour = form.get(`${prefix}_hour`) || '00'
  const minute = form.get(`${prefix}_minute`) || '00'
  return `${hour}:${minute}:00`
}

function getCompactTime(form, prefix) {
  const type = form.get(`${prefix}_time_type`) || '不指定'
  const hour = form.get(`${prefix}_hour`) || ''
  const minute = form.get(`${prefix}_minute`) || ''
  if (type === '不指定') return '不指定'
  return `${type} ${hour}:${minute}`
}

function getSelectedProxyName() {
  const proxySelect = document.querySelector('#proxyStaffSelect')
  if (!proxySelect || !proxySelect.value) return ''
  const option = proxySelect.options[proxySelect.selectedIndex]
  return option ? option.textContent : ''
}

function getStaffNameFromSelect(name) {
  const select = document.querySelector(`select[name="${name}"]`)
  if (!select || !select.value) return ''
  const option = select.options[select.selectedIndex]
  return option ? option.textContent : ''
}

function buildRepeatNote(form) {
  const mode = form.get('repeat_mode') || '單日'
  if (mode === '單日') return '行程模式：單日'
  if (mode === '連續日期') return '行程模式：連續日期'

  if (mode === '每週重複') {
    const days = [...document.querySelectorAll('input[name="repeat_weekdays"]:checked')]
      .map(input => weekdays.find(([value]) => value === input.value)?.[1] || input.value)
      .join('、')
    return `行程模式：每週重複；重複星期：${days || '未設定'}`
  }

  if (mode === '每月重複') return `行程模式：每月重複；每月 ${form.get('monthly_day') || '1'} 號`
  return `行程模式：${mode}`
}

function buildServiceExtraNotes(form, scheduleType) {
  const notes = []

  if (form.get('has_documents') === '是') {
    const docs = [...document.querySelectorAll('input[name="document_items"]:checked')]
      .map(input => input.value)
      .join('、')
    const docNote = form.get('document_note') || ''
    notes.push(`證件：${docs || '未勾選'}${docNote ? '；' + docNote : ''}`)
  }

  if (scheduleType === '醫療') {
    if (form.get('medical_next_date')) notes.push(`下次回診：${form.get('medical_next_date')} ${getCompactTime(form, 'medical_next')}`)
    if (getStaffNameFromSelect('medical_next_staff')) notes.push(`下次執行者：${getStaffNameFromSelect('medical_next_staff')}`)
    if (form.get('medical_register_no')) notes.push(`掛號號碼：${form.get('medical_register_no')}`)
  }

  if (scheduleType === '逃跑通知') {
    if (form.get('runaway_day1')) notes.push(`逃跑第一日：${form.get('runaway_day1')}`)
    if (form.get('runaway_day2')) notes.push(`逃跑第二日：${form.get('runaway_day2')}`)
    if (form.get('runaway_day3')) notes.push(`逃跑第三日：${form.get('runaway_day3')}`)
  }

  if (scheduleType === '轉出追蹤') {
    if (form.get('transfer_end_date')) notes.push(`終止日：${form.get('transfer_end_date')}`)
    if (form.get('transfer_due_date')) notes.push(`轉出到期日：${form.get('transfer_due_date')}`)
  }

  if (scheduleType === '返台提醒') {
    if (form.get('return_date')) notes.push(`返台日期：${form.get('return_date')}`)
    if (form.get('return_flight')) notes.push(`班機：${form.get('return_flight')}`)
    notes.push(`抵台時間：${getCompactTime(form, 'arrival')}`)
  }

  if (scheduleType === '住變資訊') {
    if (form.get('housing_change_date')) notes.push(`住變日期：${form.get('housing_change_date')}`)
    notes.push(`搬家時間：${getCompactTime(form, 'housing_move')}`)
    if (form.get('housing_note')) notes.push(`住變說明：${form.get('housing_note')}`)
  }

  if (scheduleType === '驗證提醒') {
    if (form.get('verify_last_work_date')) notes.push(`最後工作日：${form.get('verify_last_work_date')}`)
    if (form.get('verify_date')) notes.push(`驗證日期：${form.get('verify_date')}`)
    if (form.get('verify_leave_date')) notes.push(`離境日期：${form.get('verify_leave_date')}`)
  }

  return notes
}



function openMedicalFollowModal(scheduleId) {
  const row = schedules.find(item => item.schedule_id === scheduleId)
  if (!row) return

  if (!isMine(row)) {
    alert('只有行程建立者或被指派人員可以填寫回診資訊。')
    return
  }

  const currentDate = getNoteValue(row, '下次回診').split(' ')[0] || ''
  const currentTimeText = getNoteValue(row, '下次回診').split(' ').slice(1).join(' ')
  const currentRegisterNo = getNoteValue(row, '掛號號碼')
  const currentStaffText = getNoteValue(row, '下次執行者')

  const modal = document.createElement('div')
  modal.className = 'modal-backdrop'
  modal.innerHTML = `
    <div class="modal-panel detail-panel">
      <div class="modal-header">
        <h3>醫療回診資訊</h3>
        <button class="icon-btn" id="closeMedicalFollowBtn" type="button">×</button>
      </div>

      <div class="notice">
        回診資訊在「查看」頁填寫，不放在新增行程表單，避免新增服務行程時版面太複雜。
      </div>

      <div class="form-grid">
        <label>
          下次回診日期
          <input name="medical_next_date" id="medicalNextDateInput" type="date" value="${currentDate}">
        </label>

        <label>
          下次回診時間
          <div class="compact-time-row">
            <select id="medicalNextTimeType">
              <option value="不指定">不指定</option>
              <option value="上午">上午</option>
              <option value="下午">下午</option>
            </select>
            <select id="medicalNextHour">${hourOptionsHtml('09')}</select>
            <select id="medicalNextMinute">${minuteOptionsHtml('00')}</select>
          </div>
        </label>

        <label>
          下次執行者
          <select id="medicalNextStaffSelect">
            ${staffSelectOptionsHtml()}
          </select>
        </label>

        <label>
          掛號號碼
          <input id="medicalRegisterNoInput" value="${escapeHtml(currentRegisterNo)}" placeholder="掛號號碼">
        </label>
      </div>

      <div class="modal-actions">
        <button type="button" class="secondary-btn" id="cancelMedicalFollowBtn">取消</button>
        <button type="button" class="primary-btn" id="saveMedicalFollowBtn">儲存回診資訊</button>
      </div>
    </div>
  `

  document.body.appendChild(modal)

  if (currentTimeText.includes('上午')) document.querySelector('#medicalNextTimeType').value = '上午'
  if (currentTimeText.includes('下午')) document.querySelector('#medicalNextTimeType').value = '下午'

  const staffSelect = document.querySelector('#medicalNextStaffSelect')
  if (currentStaffText) {
    Array.from(staffSelect.options).forEach((option, index) => {
      if (option.textContent === currentStaffText) staffSelect.selectedIndex = index
    })
  }

  document.querySelector('#closeMedicalFollowBtn').addEventListener('click', () => modal.remove())
  document.querySelector('#cancelMedicalFollowBtn').addEventListener('click', () => modal.remove())
  document.querySelector('#saveMedicalFollowBtn').addEventListener('click', async () => {
    const dateValue = document.querySelector('#medicalNextDateInput').value
    const timeType = document.querySelector('#medicalNextTimeType').value
    const hour = document.querySelector('#medicalNextHour').value
    const minute = document.querySelector('#medicalNextMinute').value
    const staffId = staffSelect.value
    const staffText = staffSelect.value ? staffSelect.options[staffSelect.selectedIndex].textContent : ''
    const registerNo = document.querySelector('#medicalRegisterNoInput').value.trim()

    if (!dateValue) {
      alert('請輸入下次回診日期，系統才可以建立下一次回診行程。')
      return
    }

    if (!staffId) {
      alert('請選擇下次執行者。')
      return
    }

    const cleanNote = removeNoteLabels(row.sub_type_note, ['下次回診', '下次執行者', '掛號號碼'])
    const newParts = []
    if (cleanNote) newParts.push(cleanNote)
    if (dateValue) newParts.push(`下次回診：${dateValue} ${timeType === '不指定' ? '不指定' : timeType + ' ' + hour + ':' + minute}`)
    if (staffText) newParts.push(`下次執行者：${staffText}`)
    if (registerNo) newParts.push(`掛號號碼：${registerNo}`)

    const nextStartTime = timeType === '不指定' ? null : `${hour}:${minute}:00`

    const { error } = await supabase.rpc('save_medical_followup_and_create_schedule', {
      target_schedule_id: scheduleId,
      followup_note_value: newParts.join('｜'),
      next_date_value: dateValue,
      next_time_type_value: timeType,
      next_start_time_value: nextStartTime,
      next_staff_id_value: staffId,
      register_no_value: registerNo || null
    })

    if (error) {
      alert('更新回診資訊失敗：' + error.message)
      return
    }

    modal.remove()
    await refreshData()
    renderApp()
  })
}


function openEditScheduleModal(scheduleId) {
  const row = schedules.find(item => item.schedule_id === scheduleId)
  if (!row) return

  if (!canModifySchedule(row)) {
    alert('您沒有權限修改此行程。')
    return
  }

  const start = parseTimeForEdit(row.start_time, '09', '00')
  const end = parseTimeForEdit(row.end_time, '10', '00')
  const categoryOptions = optionHtml(formCategories, row.category)
  const serviceTypeOptions = optionHtml(serviceScheduleTypes, row.schedule_type || '其他')
  const subTypeOptions = optionHtml(serviceScheduleTypes, row.sub_type || '', true)
  const carSelectOptions = optionHtml(carOptions, row.car_no || '不使用')
  const timeOptions = timeTypeOptionsHtml(row.time_type || '不指定')
  const showTime = ['上午', '下午'].includes(row.time_type)

  const modal = document.createElement('div')
  modal.className = 'modal-backdrop'
  modal.innerHTML = `
    <div class="modal-panel">
      <div class="modal-header">
        <h3>修改行程</h3>
        <button class="icon-btn" id="closeEditModalBtn" type="button">×</button>
      </div>

      <form id="editScheduleForm" class="form-grid">
        <label>
          類別
          <select name="category" id="editCategorySelect">
            ${categoryOptions}
          </select>
        </label>

        <label>
          狀態
          <input value="${escapeHtml(row.status || '未完成')}" disabled>
        </label>

        <div class="span-2 service-grid" id="editServiceBlock">
          <label>
            行程類型
            <select name="schedule_type">
              ${serviceTypeOptions}
            </select>
          </label>

          <div class="extra-schedule-box">
            <label>
              是否有附加行程
              <select name="has_extra_schedule" id="editHasExtraScheduleSelect">
                <option value="否" ${row.sub_type ? '' : 'selected'}>否</option>
                <option value="是" ${row.sub_type ? 'selected' : ''}>是</option>
              </select>
            </label>
            <div id="editExtraScheduleBlock" class="${row.sub_type ? '' : 'hidden'}">
              <label>
                附加行程
                <select name="sub_type">
                  ${subTypeOptions}
                </select>
              </label>
            </div>
          </div>

          <div class="span-2 service-record-box">
            <div class="field-title">服務紀錄單</div>
            <label class="service-check">
              <input name="need_service_record" type="checkbox" id="editNeedServiceRecordCheck" ${row.need_service_record ? 'checked' : ''}>
              <span>需要服務紀錄單</span>
            </label>
            <label class="service-check">
              <input name="service_record_submitted_check" type="checkbox" id="editServiceRecordSubmittedCheck" ${row.service_record_submitted_date ? 'checked' : ''}>
              <span>已繳交</span>
            </label>
          </div>

          <label>
            服務紀錄單繳交日期
            <input name="service_record_submitted_date" type="date" value="${row.service_record_submitted_date || ''}">
          </label>

          <label>
            公務車
            <select name="car_no">
              ${carSelectOptions}
            </select>
          </label>
        </div>

        <div class="span-2 service-location-top" id="editServiceLocationBlock">
          <label>
            區域 / 客戶
            <input name="customer_name" value="${escapeHtml(row.customer_name || '')}">
          </label>

          <label>
            地點
            <input name="location_name" value="${escapeHtml(row.location_name || '')}">
          </label>

          <label class="span-2">
            地址
            <input name="address" value="${escapeHtml(row.address || '')}">
          </label>
        </div>

        <label class="span-2">
          標題
          <input name="title" required value="${escapeHtml(row.title || '')}">
        </label>

        <label class="span-2">
          內容
          <textarea name="description" rows="3">${escapeHtml(row.description || '')}</textarea>
        </label>

        <label>
          開始日期
          <input name="start_date" type="date" required value="${row.start_date || todayString()}">
        </label>

        <label>
          結束日期
          <input name="end_date" type="date" value="${row.end_date || row.start_date || todayString()}">
        </label>

        <label>
          時間類型
          <select name="time_type" id="editTimeTypeSelect">
            ${timeOptions}
          </select>
        </label>

        <div class="span-2 conditional-time ${showTime ? '' : 'hidden'}" id="editTimeRangeBlock">
          <div class="time-select-row">
            <label>
              開始小時
              <select name="start_hour">${hourOptionsHtml(start.hour)}</select>
            </label>
            <label>
              開始分鐘
              <select name="start_minute">${minuteOptionsHtml(start.minute)}</select>
            </label>
            <label>
              結束小時
              <select name="end_hour">${hourOptionsHtml(end.hour)}</select>
            </label>
            <label>
              結束分鐘
              <select name="end_minute">${minuteOptionsHtml(end.minute)}</select>
            </label>
          </div>
        </div>

        <label class="span-2">
          備註 / 提醒 / 證件
          <input name="sub_type_note" value="${escapeHtml(row.sub_type_note || '')}">
        </label>

        <div class="span-2 edit-assignee-box">
          <div class="field-title">執行者</div>
          <div class="checkbox-list">${editStaffOptionsHtml(row) || '<div class="empty-state">目前沒有可選人員。</div>'}</div>
          <p class="field-hint">修改執行者會同步更新個人行程表與行程總覽。</p>
        </div>

        <div class="modal-actions span-2">
          <button type="button" class="secondary-btn" id="cancelEditModalBtn">取消</button>
          <button type="submit" class="primary-btn">儲存修改</button>
        </div>
      </form>
    </div>
  `

  document.body.appendChild(modal)

  const categorySelect = document.querySelector('#editCategorySelect')
  const serviceBlock = document.querySelector('#editServiceBlock')
  const serviceLocationBlock = document.querySelector('#editServiceLocationBlock')
  const timeTypeSelect = document.querySelector('#editTimeTypeSelect')
  const timeBlock = document.querySelector('#editTimeRangeBlock')
  const needRecordCheck = document.querySelector('#editNeedServiceRecordCheck')
  const submittedCheck = document.querySelector('#editServiceRecordSubmittedCheck')
  const editHasExtraScheduleSelect = document.querySelector('#editHasExtraScheduleSelect')
  const editExtraScheduleBlock = document.querySelector('#editExtraScheduleBlock')
  const submittedDateInput = document.querySelector('input[name="service_record_submitted_date"]')

  function refreshEditServiceBlock() {
    serviceBlock.classList.toggle('hidden', categorySelect.value !== '服務行程')
    if (serviceLocationBlock) serviceLocationBlock.classList.toggle('hidden', categorySelect.value !== '服務行程')
  }

  function refreshEditTimeBlock() {
    timeBlock.classList.toggle('hidden', !['上午', '下午'].includes(timeTypeSelect.value))
  }

  function refreshEditExtraScheduleBlock() {
    if (!editHasExtraScheduleSelect || !editExtraScheduleBlock) return
    editExtraScheduleBlock.classList.toggle('hidden', editHasExtraScheduleSelect.value !== '是')
  }

  function refreshEditServiceRecordChecks() {
    if (!needRecordCheck.checked) {
      submittedCheck.checked = false
      submittedCheck.disabled = true
      submittedDateInput.value = ''
      submittedDateInput.disabled = true
    } else {
      submittedCheck.disabled = false
      submittedDateInput.disabled = !submittedCheck.checked
      if (submittedCheck.checked && !submittedDateInput.value) submittedDateInput.value = todayString()
      if (!submittedCheck.checked) submittedDateInput.value = ''
    }
  }

  categorySelect.addEventListener('change', refreshEditServiceBlock)
  timeTypeSelect.addEventListener('change', refreshEditTimeBlock)
  needRecordCheck.addEventListener('change', refreshEditServiceRecordChecks)
  submittedCheck.addEventListener('change', refreshEditServiceRecordChecks)
  if (editHasExtraScheduleSelect) editHasExtraScheduleSelect.addEventListener('change', refreshEditExtraScheduleBlock)

  refreshEditExtraScheduleBlock()
  refreshEditServiceBlock()
  refreshEditTimeBlock()
  refreshEditServiceRecordChecks()

  document.querySelector('#closeEditModalBtn').addEventListener('click', () => modal.remove())
  document.querySelector('#cancelEditModalBtn').addEventListener('click', () => modal.remove())
  document.querySelector('#editScheduleForm').addEventListener('submit', event => saveEditedSchedule(event, modal, row))
}

async function saveEditedSchedule(event, modal, originalRow) {
  event.preventDefault()

  const form = new FormData(event.target)
  const editExecutorIds = [...document.querySelectorAll('input[name="edit_executor"]:checked')].map(input => input.value)

  if (!editExecutorIds.length) {
    alert('請至少選擇一位執行者。')
    return
  }

  const category = form.get('category')
  const isService = category === '服務行程'
  const submitted = isService && form.get('service_record_submitted_check') === 'on'
  const submittedDate = submitted ? (form.get('service_record_submitted_date') || todayString()) : null

  const payload = {
    category,
    schedule_type: isService ? (form.get('schedule_type') || '其他') : category,
    sub_type: isService && form.get('has_extra_schedule') === '是' ? (form.get('sub_type') || null) : null,
    sub_type_note: form.get('sub_type_note') || null,
    title: form.get('title'),
    description: form.get('description') || null,
    start_date: form.get('start_date'),
    end_date: form.get('end_date') || form.get('start_date'),
    time_type: form.get('time_type'),
    start_time: getTimeValue(form, 'start'),
    end_time: getTimeValue(form, 'end'),
    customer_name: isService ? (form.get('customer_name') || null) : null,
    location_name: isService ? (form.get('location_name') || null) : null,
    address: isService ? (form.get('address') || null) : null,
    car_no: isService ? (form.get('car_no') || null) : null,
    need_service_record: isService && form.get('need_service_record') === 'on',
    service_record_submitted: submitted,
    service_record_submitted_date: submittedDate
  }

  const { error } = await supabase
    .from('schedules')
    .update(payload)
    .eq('schedule_id', originalRow.schedule_id)

  if (error) {
    alert('修改行程失敗：' + error.message)
    return
  }

  const { error: assigneeError } = await supabase.rpc('update_schedule_assignees', {
    target_schedule_id: originalRow.schedule_id,
    staff_ids_value: editExecutorIds
  })

  if (assigneeError) {
    alert('行程內容已修改，但執行者同步失敗：' + assigneeError.message)
    return
  }

  await supabase.from('audit_logs').insert({
    operated_by_profile_id: currentProfile.profile_id,
    operated_by_staff_id: currentProfile.staff_id,
    operated_by_name: currentProfile.name || currentProfile.email,
    action_type: '修改',
    source_type: 'schedule',
    source_id: originalRow.schedule_id,
    note: 'V002-1F 修改行程內容'
  })

  modal.remove()
  await refreshData()
  renderApp()
}


async function saveSchedule(event, modal) {
  event.preventDefault()
  if (saving) return
  saving = true
  // V002-1H-4_SAVE_GUARD
  try {

  const form = new FormData(event.target)
  const editExecutorIds = [...document.querySelectorAll('input[name="edit_executor"]:checked')].map(input => input.value)

  if (!editExecutorIds.length) {
    alert('請至少選擇一位執行者。')
    return
  }

  const category = form.get('category')
  const availableFormCategories = getAvailableFormCategories()
  if (!availableFormCategories.includes(category)) {
    alert('此頁面只能新增一般記事、待辦事項、請假 / 會議 / 活動 / 外訓。')
    saving = false
    return
  }

  const executorIds = [...document.querySelectorAll('input[name="executor"]:checked')].map(input => input.value)

  if (!executorIds.length) {
    alert('請至少選擇一位執行者。')
    saving = false
    return
  }

  if (form.get('repeat_mode') === '每週重複') {
    const checkedWeekdays = document.querySelectorAll('input[name="repeat_weekdays"]:checked')
    if (!checkedWeekdays.length) {
      alert('每週重複請至少選擇一個星期。')
      saving = false
      return
    }
  }

  const selectedStaff = staffList.filter(staff => executorIds.includes(staff.staff_id))
  const firstStaff = selectedStaff[0]
  const needServiceRecord = category === '服務行程' && form.get('need_service_record') === 'on'
  const serviceRecordSubmitted = category === '服務行程' && form.get('service_record_submitted_check') === 'on'
  const submittedDate = serviceRecordSubmitted ? (form.get('service_record_submitted_date') || todayString()) : null

  let scheduleType = ''
  let subType = ''
  let subTypeNoteParts = [buildRepeatNote(form)]
  let customerName = null
  let locationName = null
  let address = null
  let carNo = null
  let endDate = form.get('repeat_mode') === '單日'
    ? form.get('start_date')
    : (form.get('end_date') || form.get('start_date'))

  if (category === '一般記事') {
    scheduleType = '一般記事'
  }

  if (category === '待辦事項') {
    scheduleType = '待辦事項'
    subType = form.get('todo_item') || null
  }

  if (category === '請假 / 會議 / 活動 / 外訓') {
    scheduleType = form.get('leave_meeting_type') || '請假'
    subType = scheduleType
    if (getSelectedProxyName()) subTypeNoteParts.push(`代理人：${getSelectedProxyName()}`)
  }

  if (category === '服務行程') {
    scheduleType = form.get('schedule_type') || '其他'
    subType = form.get('has_extra_schedule') === '是' ? (form.get('sub_type') || null) : null
    customerName = form.get('customer_name') || null
    locationName = form.get('location_name') || null
    address = form.get('address') || null
    carNo = form.get('car_no') || null
    subTypeNoteParts.push(...buildServiceExtraNotes(form, scheduleType))
    if (form.get('sub_type_note')) subTypeNoteParts.push(form.get('sub_type_note'))
    if (needServiceRecord) subTypeNoteParts.push(`服務紀錄單：${serviceRecordSubmitted ? '已繳交' : '需要，尚未繳交'}`)
  }

  const schedulePayload = {
    creator_profile_id: currentProfile.profile_id,
    creator_staff_id: currentProfile.staff_id,
    creator_name: currentProfile.name || currentProfile.email,
    department_id: firstStaff.department_id || currentProfile.department_id,
    department_name: firstStaff.department_name || currentProfile.department_name,
    category,
    schedule_type: scheduleType,
    sub_type: subType || null,
    sub_type_note: subTypeNoteParts.filter(Boolean).join('｜'),
    title: form.get('title'),
    description: form.get('description') || null,
    start_date: form.get('start_date'),
    end_date: endDate,
    time_type: form.get('time_type'),
    start_time: getTimeValue(form, 'start'),
    end_time: getTimeValue(form, 'end'),
    customer_name: customerName,
    location_name: locationName,
    address,
    car_no: carNo,
    status: '未完成',
    need_service_record: needServiceRecord,
    service_record_submitted: Boolean(submittedDate),
    service_record_submitted_date: submittedDate
  }

  const { data: schedule, error: scheduleError } = await supabase
    .from('schedules')
    .insert(schedulePayload)
    .select()
    .single()

  if (scheduleError) {
    console.error(scheduleError)
    alert('新增行程失敗：' + scheduleError.message)
    saving = false
    return
  }

  const assigneeRows = selectedStaff.map(staff => ({
    schedule_id: schedule.schedule_id,
    staff_id: staff.staff_id,
    staff_name: staff.name,
    department_id: staff.department_id,
    department_name: staff.department_name,
    position: staff.position,
    assignee_type: 'executor'
  }))

  const { error: assigneeError } = await supabase.from('schedule_assignees').insert(assigneeRows)

  if (assigneeError) {
    console.error(assigneeError)
    alert('行程已建立，但指派人員寫入失敗：' + assigneeError.message)
    saving = false
    return
  }

  if (needServiceRecord) {
    const serviceRows = selectedStaff.map(staff => ({
      schedule_id: schedule.schedule_id,
      staff_id: staff.staff_id,
      staff_name: staff.name,
      department_id: staff.department_id,
      department_name: staff.department_name,
      schedule_date: schedulePayload.start_date,
      schedule_type: schedulePayload.schedule_type,
      title: schedulePayload.title,
      location_name: schedulePayload.location_name || schedulePayload.customer_name,
      need_submit: true,
      submitted: Boolean(submittedDate),
      submitted_date: submittedDate
    }))

    const { error: serviceError } = await supabase.from('service_records').insert(serviceRows)

    if (serviceError) {
      console.error(serviceError)
      alert('行程已建立，但服務紀錄單資料寫入失敗：' + serviceError.message)
    }
  }

  await supabase.from('audit_logs').insert({
    operated_by_profile_id: currentProfile.profile_id,
    operated_by_staff_id: currentProfile.staff_id,
    operated_by_name: currentProfile.name || currentProfile.email,
    action_type: '新增',
    source_type: 'schedule',
    source_id: schedule.schedule_id,
    note: 'V002-1E-4 新增行程'
  })

  modal.remove()
  await refreshData()
  saving = false
  renderApp()
  } catch (err) {
    console.error(err)
    alert('儲存失敗：' + (err?.message || err))
    saving = false
  }
}

async function completeSchedule(scheduleId) {
  if (!confirm('確定要將此行程標記為已完成嗎？')) return

  const { error } = await supabase.rpc('complete_schedule', {
    target_schedule_id: scheduleId
  })

  if (error) {
    alert('完成行程失敗：' + error.message)
    return
  }

  await refreshData()
  renderApp()
}

function openCancelModal(scheduleId) {
  const row = schedules.find(item => item.schedule_id === scheduleId)
  if (!row) return

  const modal = document.createElement('div')
  modal.className = 'modal-backdrop'
  modal.innerHTML = `
    <div class="modal-panel detail-panel">
      <div class="modal-header">
        <h3>取消 / 刪除行程</h3>
        <button class="icon-btn" id="closeCancelModalBtn" type="button">×</button>
      </div>

      <div class="warning-card">
        <strong>防呆提醒</strong>
        <p>系統目前會以「取消行程」方式保留紀錄，不會直接硬刪資料。</p>
      </div>

      <div class="radio-list">
        <label class="radio-row">
          <input type="radio" name="deleteScope" value="只刪今天" checked>
          <span>
            <strong>只刪今天</strong>
            <small>只取消這一筆行程，其他週期行程不受影響。</small>
          </span>
        </label>

        <label class="radio-row">
          <input type="radio" name="deleteScope" value="刪除之後行程（包含今天）">
          <span>
            <strong>刪除之後行程（包含今天）</strong>
            <small>保留今天以前的行程，取消今天與之後的週期行程。</small>
          </span>
        </label>

        <label class="radio-row danger-option">
          <input type="radio" name="deleteScope" value="刪除全部行程">
          <span>
            <strong>刪除全部行程</strong>
            <small>取消整組週期行程，影響最大。</small>
          </span>
        </label>
      </div>

      <label>
        取消原因
        <textarea id="cancelReasonInput" rows="3" placeholder="請輸入取消原因"></textarea>
      </label>

      <div id="deleteAllConfirmBlock" class="hidden">
        <label>
          若選擇「刪除全部行程」，請輸入：刪除全部
          <input id="deleteAllConfirmInput" placeholder="請輸入 刪除全部">
        </label>
      </div>

      <div class="modal-actions">
        <button type="button" class="secondary-btn" id="cancelCancelBtn">返回</button>
        <button type="button" class="danger-btn" id="confirmCancelBtn">確認取消</button>
      </div>
    </div>
  `

  document.body.appendChild(modal)

  function refreshDeleteAllBlock() {
    const scope = document.querySelector('input[name="deleteScope"]:checked')?.value
    document.querySelector('#deleteAllConfirmBlock').classList.toggle('hidden', scope !== '刪除全部行程')
  }

  document.querySelectorAll('input[name="deleteScope"]').forEach(input => {
    input.addEventListener('change', refreshDeleteAllBlock)
  })

  document.querySelector('#closeCancelModalBtn').addEventListener('click', () => modal.remove())
  document.querySelector('#cancelCancelBtn').addEventListener('click', () => modal.remove())
  document.querySelector('#confirmCancelBtn').addEventListener('click', async () => {
    const scope = document.querySelector('input[name="deleteScope"]:checked')?.value || '只刪今天'
    const reason = document.querySelector('#cancelReasonInput').value.trim()

    if (!reason) {
      alert('請輸入取消原因。')
      return
    }

    if (scope === '刪除全部行程') {
      const confirmText = document.querySelector('#deleteAllConfirmInput').value.trim()
      if (confirmText !== '刪除全部') {
        alert('刪除全部行程需輸入「刪除全部」才可繼續。')
        return
      }
    }

    const finalReason = `${scope}｜${reason}`
    modal.remove()
    await cancelSchedule(scheduleId, finalReason)
  })

  refreshDeleteAllBlock()
}

async function cancelSchedule(scheduleId, reason) {
  const { error } = await supabase.rpc('cancel_schedule', {
    target_schedule_id: scheduleId,
    cancel_note: reason
  })

  if (error) {
    alert('取消行程失敗：' + error.message)
    return
  }

  await refreshData()
  renderApp()
}


function openServiceRecordModal(scheduleId) {
  const row = schedules.find(item => item.schedule_id === scheduleId)
  if (!row) return

  const modal = document.createElement('div')
  modal.className = 'modal-backdrop'
  modal.innerHTML = `
    <div class="modal-panel detail-panel">
      <div class="modal-header">
        <h3>服務紀錄單繳交狀況</h3>
        <button class="icon-btn" id="closeRecordModalBtn" type="button">×</button>
      </div>

      <div class="notice">
        行程完成狀態與服務紀錄單繳交狀態分開管理。此處只更新服務紀錄單，不會改變行程是否完成。
      </div>

      <div class="detail-grid">
        <div class="span-2"><span>行程</span><strong>${escapeHtml(row.schedule_type || row.category)}｜${escapeHtml(row.title)}</strong></div>
        <div><span>行程日期</span><strong>${escapeHtml(row.start_date || '-')}</strong></div>
        <div><span>目前狀態</span><strong>${row.service_record_submitted_date ? '已繳交：' + row.service_record_submitted_date : '尚未繳交'}</strong></div>
      </div>

      <label class="service-check record-modal-check">
        <input id="recordSubmittedInput" type="checkbox" ${row.service_record_submitted_date ? 'checked' : ''}>
        <span>已繳交服務紀錄單</span>
      </label>

      <label>
        繳交日期
        <input id="recordSubmittedDateInput" type="date" value="${row.service_record_submitted_date || todayString()}">
      </label>

      <div class="modal-actions">
        <button type="button" class="secondary-btn" id="closeRecordModalBtn2">取消</button>
        <button type="button" class="primary-btn" id="saveRecordStatusBtn">儲存紀錄單狀況</button>
      </div>
    </div>
  `

  document.body.appendChild(modal)

  const submittedInput = document.querySelector('#recordSubmittedInput')
  const dateInput = document.querySelector('#recordSubmittedDateInput')

  function refreshRecordDate() {
    dateInput.disabled = !submittedInput.checked
    if (submittedInput.checked && !dateInput.value) dateInput.value = todayString()
    if (!submittedInput.checked) dateInput.value = ''
  }

  submittedInput.addEventListener('change', refreshRecordDate)
  refreshRecordDate()

  document.querySelector('#closeRecordModalBtn').addEventListener('click', () => modal.remove())
  document.querySelector('#closeRecordModalBtn2').addEventListener('click', () => modal.remove())
  document.querySelector('#saveRecordStatusBtn').addEventListener('click', async () => {
    const submitted = submittedInput.checked
    const submittedDate = submitted ? dateInput.value : null

    if (submitted && !submittedDate) {
      alert('請輸入服務紀錄單繳交日期。')
      return
    }

    const { error } = await supabase.rpc('update_service_record_status', {
      target_schedule_id: scheduleId,
      submitted_value: submitted,
      submitted_date_value: submittedDate
    })

    if (error) {
      alert('更新服務紀錄單狀況失敗：' + error.message)
      return
    }

    modal.remove()
    await refreshData()
    renderApp()
  })
}


async function logout() {
  await supabase.auth.signOut()
  currentProfile = null
  renderLogin()
}

window.addEventListener('load', loadProfile)

/* FOR-e V002-1H-5-7 START - special schedule fields */
(function () {
  if (typeof window === 'undefined' || typeof document === 'undefined') return;

  /*
    V002-1H-5-7｜特殊行程類型表單欄位安全隱藏

    觸發行程類型：
    逃跑、轉出、住變、驗證、返台、宿舍

    原則：
    1. 只做畫面隱藏。
    2. 不改行程類型選項。
    3. 不改 Supabase。
    4. 不改原本新增 / 修改 / 儲存流程。
    5. 不刪除欄位、不移除 DOM 結構。
    6. 隱藏欄位如果原本有 required，暫時移除，避免儲存被擋；切回一般行程時會還原。
  */

  const SPECIAL_TYPE_KEYWORDS = [
    '逃跑',
    '轉出',
    '住變',
    '驗證',
    '返台',
    '宿舍',
  ];

  const SCHEDULE_TYPE_LABEL = '行程類型';

  const HIDE_FIELD_LABELS = [
    '是否有附加行程',
    '附加行程備註',
    '附加行程',
    '服務紀錄單',
    '公務車',
    '是否有證件',
    '證件勾選',
    '證件 / 文件備註',
    '證件/文件備註',
    '證件備註',
    '文件備註',
    '證件',
    '醫療回診',
    '是否回診',
    '回診資訊',
    '回診日期',
    '回診時間',
    '下次回診',
    '下次回診日期',
    '下次回診時間',
  ];

  const FIELD_CONTAINER_SELECTORS = [
    '.form-row',
    '.form-group',
    '.form-field',
    '.field-row',
    '.field',
    '.input-row',
    '.input-group',
    '.modal-row',
    '.schedule-form-row',
    '.schedule-field',
    '[data-field]',
  ].join(',');

  const FORM_ROOT_SELECTORS = [
    'form',
    '[role="dialog"]',
    'dialog',
    '.modal',
    '.dialog',
    '.popup',
    '.drawer',
    '.schedule-modal',
    '.form-card',
    '.panel',
    '.card',
    'main',
    '#app',
  ].join(',');

  const LABEL_SELECTORS = [
    'label',
    '.form-label',
    '.field-label',
    '.label',
    '.form-row',
    '.form-group',
    '.form-field',
    '.field-row',
    '.field',
    '.input-row',
    '.input-group',
    '[data-field]',
    'span',
    'div',
    'p',
    'strong',
  ].join(',');

  function normalize(value) {
    return String(value || '')
      .replace(/\s+/g, '')
      .replace(/[：:]/g, '')
      .trim();
  }

  function ownReadableText(element) {
    if (!element) return '';

    const clone = element.cloneNode(true);

    clone.querySelectorAll('input, select, textarea, button, option, svg, img').forEach((node) => {
      node.remove();
    });

    return normalize(clone.textContent);
  }

  function textIncludesLabel(element, label) {
    if (!element) return false;

    const own = ownReadableText(element);
    const all = normalize(element.textContent);
    const target = normalize(label);

    if (!target) return false;

    if (label === '附加行程') {
      return (
        (own === target || all === target || own.startsWith(target)) &&
        !own.includes(normalize('是否有附加行程')) &&
        !own.includes(normalize('附加行程備註')) &&
        !all.includes(normalize('是否有附加行程')) &&
        !all.includes(normalize('附加行程備註'))
      );
    }

    if (label === '證件') {
      return (
        own === target ||
        own.startsWith(target) ||
        all === target ||
        all.startsWith(target) ||
        all.includes(normalize('證件勾選')) ||
        all.includes(normalize('證件備註')) ||
        all.includes(normalize('是否有證件'))
      );
    }

    return own.includes(target) || all.includes(target);
  }

  function countKnownFieldWords(text) {
    const normalized = normalize(text);
    const words = [
      '執行狀況',
      '類型',
      '日期',
      '週期',
      '時間',
      '行程類型',
      '區域',
      '客戶',
      '地點',
      '地址',
      '標題',
      '內容',
      '執行者',
      '是否有附加行程',
      '附加行程',
      '附加行程備註',
      '服務紀錄單',
      '公務車',
      '是否有證件',
      '證件',
      '備註',
      '回診',
    ];

    const found = new Set();

    words.forEach((word) => {
      if (normalized.includes(normalize(word))) {
        found.add(word);
      }
    });

    if (normalized.includes(normalize('是否有附加行程'))) {
      found.delete('附加行程');
    }

    if (normalized.includes(normalize('附加行程備註'))) {
      found.delete('附加行程');
      found.delete('備註');
    }

    if (normalized.includes(normalize('行程類型'))) {
      found.delete('類型');
    }

    return found.size;
  }

  function isReasonableFieldBlock(element) {
    if (!element || element === document.body || element === document.documentElement) return false;

    const text = normalize(element.textContent);

    if (!text || text.length > 500) return false;

    const controls = element.querySelectorAll('input, select, textarea');

    if (!controls.length) return false;

    return countKnownFieldWords(text) <= 3;
  }

  function closestFieldBlock(labelElement) {
    if (!labelElement) return null;

    const direct = labelElement.closest(FIELD_CONTAINER_SELECTORS);

    if (direct && isReasonableFieldBlock(direct)) {
      return direct;
    }

    let current = labelElement;

    for (let depth = 0; current && depth < 8; depth += 1) {
      if (isReasonableFieldBlock(current)) {
        return current;
      }

      current = current.parentElement;
    }

    return labelElement.parentElement || labelElement;
  }

  function nearestFormRoot(element) {
    return element.closest(FORM_ROOT_SELECTORS) || document;
  }

  function findFieldBlocksByLabel(root, label) {
    if (!root || !root.querySelectorAll) return [];

    const blocks = [];

    Array.from(root.querySelectorAll(LABEL_SELECTORS)).forEach((element) => {
      if (!textIncludesLabel(element, label)) return;

      const block = closestFieldBlock(element);

      if (block && !blocks.includes(block)) {
        blocks.push(block);
      }
    });

    return blocks;
  }

  function getControlDisplayText(control) {
    if (!control) return '';

    const tag = control.tagName ? control.tagName.toLowerCase() : '';

    if (tag === 'select') {
      const selected = control.selectedOptions && control.selectedOptions[0];
      return `${control.value || ''} ${selected ? selected.textContent || '' : ''}`;
    }

    if (control.type === 'radio' || control.type === 'checkbox') {
      const label = control.closest('label');
      return `${control.value || ''} ${label ? label.textContent || '' : ''}`;
    }

    return control.value || '';
  }

  function valueMatchesSpecialType(value) {
    const text = normalize(value);

    return SPECIAL_TYPE_KEYWORDS.some((keyword) => text.includes(normalize(keyword)));
  }

  function blockHasSpecialTypeSelected(block) {
    if (!block) return false;

    const controls = Array.from(block.querySelectorAll('select, input'));

    return controls.some((control) => {
      if (control.type === 'radio' || control.type === 'checkbox') {
        if (!control.checked) return false;
        return valueMatchesSpecialType(getControlDisplayText(control));
      }

      return valueMatchesSpecialType(getControlDisplayText(control));
    });
  }

  function restoreRequired(control) {
    if (!control || !control.dataset) return;

    if (control.dataset.forESpecialWasRequired === 'true') {
      control.required = true;
    }

    delete control.dataset.forESpecialWasRequired;
  }

  function suspendRequired(control) {
    if (!control || !control.dataset) return;

    if (control.required) {
      control.dataset.forESpecialWasRequired = 'true';
      control.required = false;
    }
  }

  function applyFieldVisibility(block, shouldHide) {
    if (!block) return;

    block.classList.toggle('for-e-special-schedule-hidden', shouldHide);

    Array.from(block.querySelectorAll('input, select, textarea')).forEach((control) => {
      if (shouldHide) {
        suspendRequired(control);
      } else {
        restoreRequired(control);
      }
    });
  }

  function applyToRoot(root, shouldUseSpecialFields) {
    const blocksToHide = [];

    HIDE_FIELD_LABELS.forEach((label) => {
      findFieldBlocksByLabel(root, label).forEach((block) => {
        if (!blocksToHide.includes(block)) {
          blocksToHide.push(block);
        }
      });
    });

    blocksToHide.forEach((block) => {
      block.classList.add('for-e-special-schedule-controlled');
      applyFieldVisibility(block, shouldUseSpecialFields);
    });
  }

  function findScheduleTypeBlocks() {
    return findFieldBlocksByLabel(document, SCHEDULE_TYPE_LABEL).filter((block) => {
      return block.querySelector('select, input');
    });
  }

  function applySpecialScheduleFields() {
    findScheduleTypeBlocks().forEach((typeBlock) => {
      const root = nearestFormRoot(typeBlock);
      const isSpecial = blockHasSpecialTypeSelected(typeBlock);

      applyToRoot(root, isSpecial);
    });
  }

  let scheduled = false;

  function scheduleApply() {
    if (scheduled) return;

    scheduled = true;

    const run = window.requestAnimationFrame || function (callback) {
      return window.setTimeout(callback, 16);
    };

    run(() => {
      scheduled = false;
      applySpecialScheduleFields();
    });
  }

  function init() {
    applySpecialScheduleFields();

    document.addEventListener('change', (event) => {
      const target = event.target;

      if (!target || !target.closest) return;

      const root = nearestFormRoot(target);

      if (!root) return;

      const scheduleTypeBlocks = findFieldBlocksByLabel(root, SCHEDULE_TYPE_LABEL);

      if (!scheduleTypeBlocks.length) return;

      const isInsideScheduleForm = scheduleTypeBlocks.some((block) => {
        return block.contains(target) || root.contains(block);
      });

      if (!isInsideScheduleForm) return;

      scheduleApply();
    });

    document.addEventListener('input', scheduleApply);

    const observer = new MutationObserver(scheduleApply);

    observer.observe(document.body, {
      childList: true,
      subtree: true,
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init, { once: true });
  } else {
    init();
  }
})();
/* FOR-e V002-1H-5-7 END - special schedule fields */

/* FOR-e V002-1H-5-7-1 START */
(function () {
  if (typeof window === 'undefined' || typeof document === 'undefined') return;

  const EXACT_SPECIAL_TYPES = [
    '逃跑通知',
    '轉出追蹤',
    '住變資訊',
    '驗證提醒',
    '返台提醒',
    '宿舍'
  ];

  const SCHEDULE_TYPE_LABEL = '行程類型';

  const HIDE_FIELD_LABELS = [
    '是否有附加行程',
    '附加行程',
    '附加行程備註',
    '服務紀錄單',
    '公務車',
    '是否有證件',
    '證件勾選',
    '證件 / 文件備註',
    '證件/文件備註',
    '證件備註',
    '文件備註',
    '證件',
    '醫療回診',
    '是否回診',
    '回診資訊',
    '回診日期',
    '回診時間',
    '下次回診',
    '下次回診日期',
    '下次回診時間'
  ];

  const FIELD_CONTAINER_SELECTORS = [
    '.form-row',
    '.form-group',
    '.form-field',
    '.field-row',
    '.field',
    '.input-row',
    '.input-group',
    '.modal-row',
    '.schedule-form-row',
    '.schedule-field',
    '[data-field]'
  ].join(',');

  const ROOT_SELECTORS = [
    'form',
    '[role="dialog"]',
    'dialog',
    '.modal',
    '.dialog',
    '.popup',
    '.drawer',
    '.schedule-modal',
    '.form-card',
    '.panel',
    '.card',
    'main',
    '#app'
  ].join(',');

  const LABEL_SELECTORS = [
    'label',
    '.form-label',
    '.field-label',
    '.label',
    'span',
    'strong',
    'div',
    'p',
    '.form-row',
    '.form-group',
    '.form-field',
    '.field-row',
    '.field',
    '.input-row',
    '.input-group',
    '[data-field]'
  ].join(',');

  function normalize(value) {
    return String(value || '')
      .replace(/\s+/g, '')
      .replace(/[：:]/g, '')
      .trim();
  }

  function cleanOwnText(element) {
    if (!element) return '';
    const clone = element.cloneNode(true);
    clone.querySelectorAll('input, select, textarea, button, option, img, svg').forEach(node => node.remove());
    return normalize(clone.textContent);
  }

  function labelMatches(element, label) {
    const target = normalize(label);
    const own = cleanOwnText(element);
    const full = normalize(element.textContent);

    if (label === '附加行程') {
      return (
        (own === target or own.startswith(target) if False else False)
      )
    }

    return own == target or full == target or own.includes(target) or full.includes(target);
  }

  function safeLabelMatches(element, label) {
    const target = normalize(label);
    const own = cleanOwnText(element);
    const full = normalize(element.textContent);

    if (label === '附加行程') {
      const hit = own === target or full === target or own.startswith(target) or full.startswith(target);
      const bad = own.includes(normalize('是否有附加行程')) or full.includes(normalize('是否有附加行程')) or own.includes(normalize('附加行程備註')) or full.includes(normalize('附加行程備註'));
      return hit && !bad;
    }

    if (label === '證件') {
      return (
        own === target or full === target or
        own.startswith(target) or full.startswith(target) or
        full.includes(normalize('證件勾選')) or
        full.includes(normalize('證件備註')) or
        full.includes(normalize('是否有證件'))
      );
    }

    return own === target or full === target or own.includes(target) or full.includes(target);
  }

  function countFieldKeywords(text) {
    const normalized = normalize(text);
    const keywords = [
      '執行狀況', '類型', '日期', '週期', '時間', '行程類型',
      '區域', '客戶', '地點', '地址', '標題', '內容', '執行者',
      '是否有附加行程', '附加行程', '附加行程備註',
      '服務紀錄單', '公務車', '是否有證件', '證件', '回診'
    ];
    let count = 0;
    keywords.forEach(k => {
      if (normalized.includes(normalize(k))) count += 1;
    });
    return count;
  }

  function isFieldBlock(element) {
    if (!element || element === document.body || element === document.documentElement) return false;
    const text = normalize(element.textContent);
    if (!text || text.length > 500) return false;
    if (element.querySelectorAll('input, select, textarea').length === 0) return false;
    return countFieldKeywords(text) <= 4;
  }

  function closestFieldBlock(element) {
    const direct = element.closest(FIELD_CONTAINER_SELECTORS);
    if (direct && isFieldBlock(direct)) return direct;

    let current = element;
    for (let i = 0; current && i < 8; i += 1) {
      if (isFieldBlock(current)) return current;
      current = current.parentElement;
    }

    return element.parentElement || element;
  }

  function nearestRoot(element) {
    return element.closest(ROOT_SELECTORS) || document;
  }

  function findFieldBlocksByLabel(root, label) {
    const result = [];
    if (!root || !root.querySelectorAll) return result;

    Array.from(root.querySelectorAll(LABEL_SELECTORS)).forEach(element => {
      if (!safeLabelMatches(element, label)) return;
      const block = closestFieldBlock(element);
      if (block && !result.includes(block)) result.push(block);
    });

    return result;
  }

  function getSelectedTypeValue(typeBlock) {
    if (!typeBlock) return '';

    const select = typeBlock.querySelector('select');
    if (select) {
      const selected = select.selectedOptions && select.selectedOptions[0];
      return normalize(selected ? selected.textContent || selected.value || '' : select.value || '');
    }

    const checkedRadio = typeBlock.querySelector('input[type="radio"]:checked');
    if (checkedRadio) {
      const wrap = checkedRadio.closest('label');
      return normalize((wrap ? wrap.textContent : '') || checkedRadio.value || '');
    }

    const input = typeBlock.querySelector('input:not([type="hidden"])');
    if (input) {
      return normalize(input.value || '');
    }

    return '';
  }

  function isSpecialType(typeValue) {
    return EXACT_SPECIAL_TYPES.some(name => normalize(name) === normalize(typeValue));
  }

  function suspendRequired(control) {
    if (control.required) {
      control.dataset.foreSpecialRequired = '1';
      control.required = false;
    }
  }

  function restoreRequired(control) {
    if (control.dataset.foreSpecialRequired === '1') {
      control.required = true;
      delete control.dataset.foreSpecialRequired;
    }
  }

  function setFieldHidden(block, hidden) {
    block.classList.toggle('for-e-special-type-hidden', hidden);
    Array.from(block.querySelectorAll('input, select, textarea')).forEach(control => {
      if (hidden) suspendRequired(control);
      else restoreRequired(control);
    });
  }

  function applySpecialFields(root, specialMode) {
    const controlledBlocks = [];

    HIDE_FIELD_LABELS.forEach(label => {
      findFieldBlocksByLabel(root, label).forEach(block => {
        if (!controlledBlocks.includes(block)) controlledBlocks.push(block);
      });
    });

    controlledBlocks.forEach(block => {
      block.classList.add('for-e-special-type-controlled');
      setFieldHidden(block, specialMode);
    });
  }

  function refreshSpecialTypeFields() {
    findFieldBlocksByLabel(document, SCHEDULE_TYPE_LABEL).forEach(typeBlock => {
      const root = nearestRoot(typeBlock);
      const typeValue = getSelectedTypeValue(typeBlock);
      applySpecialFields(root, isSpecialType(typeValue));
    });
  }

  function findBrandBlocks() {
    const selectors = [
      'aside', 'nav', 'header', '.sidebar', '.sidebar-header', '.brand',
      '.logo', '.logo-wrap', '.app-brand', '.app-logo', '.topbar',
      '.drawer-header', '.mobile-header'
    ].join(',');

    return Array.from(document.querySelectorAll(selectors)).filter(block => {
      const hasImage = !!block.querySelector('img');
      const text = normalize(block.textContent);
      return hasImage && (text.includes(normalize('FOR-e')) || text.includes(normalize('共享排程系統')));
    });
  }

  function findTextElement(root, text) {
    const target = normalize(text);
    return Array.from(root.querySelectorAll('span, div, p, strong, h1, h2, h3, a'))
      .find(el => normalize(el.textContent).includes(target));
  }

  function enhanceBrandBlock(block) {
    if (!block || block.dataset.foreBrandDone === '1') return;

    const img = block.querySelector('img');
    if (!img) return;

    const wordEl = findTextElement(block, 'FOR-e');
    const subEl = findTextElement(block, '共享排程系統');

    block.dataset.foreBrandDone = '1';
    block.classList.add('for-e-brand-block');

    if (block.closest('aside, .sidebar, nav')) {
      block.classList.add('for-e-brand-sidebar');
    } else {
      block.classList.add('for-e-brand-top');
    }

    img.classList.add('for-e-brand-icon');
    img.style.background = 'transparent';

    if (wordEl) wordEl.classList.add('for-e-brand-word');
    if (subEl) subEl.classList.add('for-e-brand-subtitle');

    let row = block.querySelector('.for-e-brand-row');
    if (!row) {
      row = document.createElement('div');
      row.className = 'for-e-brand-row';
      block.insertBefore(row, block.firstChild);
    }

    if (img.parentElement !== row) row.appendChild(img);
    if (wordEl && wordEl.parentElement !== row) row.appendChild(wordEl);

    if (subEl && subEl !== row && subEl.parentElement !== block) {
      block.appendChild(subEl);
    }
  }

  function refreshBrandLayout() {
    findBrandBlocks().forEach(enhanceBrandBlock);
  }

  let scheduled = false;
  function scheduleRefresh() {
    if (scheduled) return;
    scheduled = true;
    const run = window.requestAnimationFrame || function (cb) { return setTimeout(cb, 16); };
    run(() => {
      scheduled = false;
      refreshSpecialTypeFields();
      refreshBrandLayout();
    });
  }

  function init() {
    refreshSpecialTypeFields();
    refreshBrandLayout();

    document.addEventListener('change', scheduleRefresh);
    document.addEventListener('input', scheduleRefresh);
    window.addEventListener('resize', scheduleRefresh);

    const observer = new MutationObserver(scheduleRefresh);
    observer.observe(document.body, { childList: true, subtree: true });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init, { once: true });
  } else {
    init();
  }
})();
/* FOR-e V002-1H-5-7-1 END */
